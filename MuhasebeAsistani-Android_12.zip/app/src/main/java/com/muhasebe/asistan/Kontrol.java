package com.muhasebe.asistan;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.view.KeyEvent;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Telefona dokunmadan yönetim: müzik/video kontrolü, ses seviyesi, fener, YouTube'da şarkı bulma, uygulama türleri. */
public final class Kontrol {
    private Kontrol() {}

    public static String sade(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(new Locale("tr", "TR"));
        t = t.replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i').replace('ö', 'o').replace('ş', 's').replace('ü', 'u').replace("̇", "");
        return t.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    // ---------------- YouTube: aranan şarkının/videonun kimliğini bul ----------------
    private static final Pattern VIDEO = Pattern.compile("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"");
    private static final Pattern HERHANGI = Pattern.compile("\"videoId\":\"([A-Za-z0-9_-]{11})\"");

    /** YouTube'da arar, reklam ve Shorts olmayan ilk videonun kimliğini döndürür (bulamazsa null). Ağ işlemi: arka planda çağır. */
    public static String youtubeBul(String sorgu) {
        HttpURLConnection c = null;
        try {
            String u = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(sorgu, "UTF-8") + "&hl=tr&gl=TR";
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
            c.setRequestProperty("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.5");
            c.setRequestProperty("Cookie", "CONSENT=YES+cb; SOCS=CAI");
            if (c.getResponseCode() != 200) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] b = new byte[32768];
                int n;
                while ((n = in.read(b)) > 0 && out.size() < 3_000_000) {
                    out.write(b, 0, n);
                    // ilk gerçek video sonucu genelde ilk ~600 KB içinde: bulunca erken bırak
                    if (out.size() > 200_000 && out.size() % 131072 < 32768) {
                        Matcher m = VIDEO.matcher(out.toString("UTF-8"));
                        if (m.find()) return m.group(1);
                    }
                }
            }
            String html = out.toString("UTF-8");
            Matcher m = VIDEO.matcher(html);
            if (m.find()) return m.group(1);
            m = HERHANGI.matcher(html);
            return m.find() ? m.group(1) : null;
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ---------------- medya, ses, fener ----------------
    public static void medyaTusu(Context c, int tus) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return;
        long t = SystemClock.uptimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, tus, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, tus, 0));
    }

    /** yon: "ac" | "kis" | "sessiz" | "sesli" ; yuzde >= 0 ise o seviyeye ayarla */
    public static void sesSeviyesi(Context c, String yon, int yuzde) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return;
        int s = AudioManager.STREAM_MUSIC;
        try {
            if (yuzde >= 0) {
                int max = am.getStreamMaxVolume(s);
                am.setStreamVolume(s, Math.max(0, Math.min(max, Math.round(max * yuzde / 100f))), AudioManager.FLAG_SHOW_UI);
            } else if ("sessiz".equals(yon)) am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
            else if ("sesli".equals(yon)) am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI);
            else {
                int d = "ac".equals(yon) ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
                for (int i = 0; i < 3; i++) am.adjustStreamVolume(s, d, i == 2 ? AudioManager.FLAG_SHOW_UI : 0);
            }
        } catch (Exception ignored) {
        }
    }

    public static boolean fener(Context c, boolean acik) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) { cm.setTorchMode(id, acik); return true; }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    /**
     * Uygulamayı öne getirmeden hemen yapılabilecek komutlar (müzik/video çalarken bile).
     * Yapılırsa kullanıcıya söylenecek kısa cevabı, değilse null döndürür.
     */
    public static String hizliKomut(Context c, String metin) {
        String k = " " + sade(metin) + " ";
        int kelime = k.trim().isEmpty() ? 0 : k.trim().split(" ").length;
        if (kelime == 0 || kelime > 7) return null;
        if (k.contains(" alarm") || k.contains(" zamanlay") || k.contains(" sayac") || k.contains(" ayar")) return null;

        // fener
        if (k.contains(" fener") || k.contains(" flas")) {
            boolean ac = !(k.contains(" kapat") || k.contains(" sondur"));
            return fener(c, ac) ? (ac ? "Feneri açtım." : "Feneri kapattım.") : "Bu telefonda fener bulamadım.";
        }
        // ses seviyesi
        Matcher yz = Pattern.compile(" ses\\S* (?:seviyesini )?(?:yuzde )?(\\d{1,3})").matcher(k);
        if (yz.find()) { int y = Math.min(100, Integer.parseInt(yz.group(1))); sesSeviyesi(c, "", y); return "Sesi yüzde " + y + " yaptım."; }
        if (k.matches(".* ses\\S* .*(ac|yukselt|artir|yukari|fazla|daha yuksek).*") && !k.contains(" kis")) { sesSeviyesi(c, "ac", -1); return "Sesi açtım."; }
        if (k.matches(".* ses\\S* .*(kis|azalt|dusur|asagi|alcalt).*") || k.contains(" daha kisik")) { sesSeviyesi(c, "kis", -1); return "Sesi kıstım."; }
        if (k.contains(" sessize al") || k.matches(".* sesi (kapat|kes) .*")) { sesSeviyesi(c, "sessiz", -1); return "Sessize aldım."; }

        // müzik / video kontrolü
        String m = k.replaceAll(" (muzigi|muzik|sarkiyi|sarki|videoyu|video|youtube u|youtube|spotify i|spotify|lutfen|bi|bir|hemen|sunu) ", " ").replaceAll("\\s+", " ").trim();
        if (m.matches("(durdur|duraklat|dur|pause|beklet|kapat|sustur)")) { medyaTusu(c, KeyEvent.KEYCODE_MEDIA_PAUSE); return "Durdurdum."; }
        if (m.matches("(devam et|devam|devam ettir|oynat|baslat|kaldigi yerden devam et|play)")) { medyaTusu(c, KeyEvent.KEYCODE_MEDIA_PLAY); return "Devam ediyor."; }
        if (m.matches("(sonraki|sonrakine gec|sonraki sarki|gec|atla|siradaki|digerine gec|baska sarki|degistir)")) { medyaTusu(c, KeyEvent.KEYCODE_MEDIA_NEXT); return "Sonrakine geçtim."; }
        if (m.matches("(onceki|oncekine don|onceki sarki|geri don|basa sar|basa al)")) { medyaTusu(c, KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Öncekine döndüm."; }
        return null;
    }

    // ---------------- uygulama türleri ("kamerayı aç", "galeriyi aç"...) ----------------
    public static Intent turIntent(String adSade) {
        String q = " " + adSade + " ";
        if (q.matches(".* (kamera|kamerayi|fotograf cek|foto cek) .*")) return new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        if (q.contains(" video cek")) return new Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA);
        if (q.matches(".* (ayarlar|ayarlari|telefon ayarlari) .*")) return new Intent(android.provider.Settings.ACTION_SETTINGS);
        if (q.matches(".* (saat|saati|alarmlar|alarmlari) .*")) return new Intent(AlarmClock.ACTION_SHOW_ALARMS);
        if (q.matches(".* (telefon|telefonu|arama|tus takimi|cevirici) .*")) return new Intent(Intent.ACTION_DIAL);
        String kat = null;
        if (q.matches(".* (hesap makinesi|hesap makinasi|hesap makinesini|hesap makinasini) .*")) kat = Intent.CATEGORY_APP_CALCULATOR;
        else if (q.matches(".* (galeri|galeriyi|fotograflar|fotograflari|resimler|resimleri|albumler) .*")) kat = Intent.CATEGORY_APP_GALLERY;
        else if (q.matches(".* (mesajlar|mesajlari|sms|mesaj) .*")) kat = Intent.CATEGORY_APP_MESSAGING;
        else if (q.matches(".* (rehber|rehberi|kisiler|kisileri) .*")) kat = Intent.CATEGORY_APP_CONTACTS;
        else if (q.matches(".* (harita|haritalar|haritayi|haritalari) .*")) kat = Intent.CATEGORY_APP_MAPS;
        else if (q.matches(".* (tarayici|tarayiciyi|internet|interneti) .*")) kat = Intent.CATEGORY_APP_BROWSER;
        else if (q.matches(".* (e posta|eposta|mail|maili|postalar) .*")) kat = Intent.CATEGORY_APP_EMAIL;
        else if (q.matches(".* (takvim|takvimi) .*")) kat = Intent.CATEGORY_APP_CALENDAR;
        else if (q.matches(".* (muzik|muzigi|muzik calar) .*")) kat = Intent.CATEGORY_APP_MUSIC;
        else if (q.matches(".* (dosyalar|dosyalari|dosya yoneticisi) .*") && android.os.Build.VERSION.SDK_INT >= 29) kat = Intent.CATEGORY_APP_FILES;
        return kat == null ? null : Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, kat);
    }

    /** Konuşmada sık duyulan farklı söylenişler → uygulamanın gerçek adı. */
    public static String takmaAd(String adBitisik) {
        switch (adBitisik) {
            case "insta": case "instegram": case "instgram": return "instagram";
            case "face": case "fesbuk": case "feysbuk": return "facebook";
            case "vatsap": case "watsap": case "whatsup": case "wp": case "wa": case "vatsapp": return "whatsapp";
            case "tiktak": case "tiktok": return "tiktok";
            case "twitter": case "x": return "x";
            case "youtubemuzik": case "youtubemusic": case "ytmusic": return "youtubemusic";
            case "yutup": case "yutub": case "youtub": return "youtube";
            case "playstore": case "market": case "googleplay": case "playmarket": return "playstore";
            case "gmail": case "jimeyl": return "gmail";
            case "spotfy": case "spotifay": return "spotify";
            case "telegram": case "telegramm": return "telegram";
            default: return adBitisik;
        }
    }
}
