package com.muhasebe.asistan;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Locale;

/** Uygulama kapalıyken uyandırma kelimesini dinler; duyunca asistanı açar. */
public class WakeService extends Service implements RecognitionListener {
    public static final String DURAKLAT = "com.muhasebe.asistan.DURAKLAT";
    public static final String DEVAM = "com.muhasebe.asistan.DEVAM";

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer tanima;
    private boolean aktif = true;
    private boolean duraklat = false;
    private boolean tetiklendi = false;
    private String kelime = "asistan";
    private final ArrayList<String> kelimeler = new ArrayList<>();
    private boolean duyuldu = false;
    private String sonMetin = "";
    private boolean komutBekle = false;
    private long komutBitis = 0; // müzik/video çalarken "Asistan" denince: uygulamayı açmadan komutu bekle
    public static volatile boolean calisiyor = false;

    @Override
    public IBinder onBind(Intent i) { return null; }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(new Locale("tr", "TR")).replaceAll("[^a-z0-9çğıöşü ]", " ").replaceAll("\\s+", " ").trim();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        kelimeleriYukle();
        Notification n = Bildirim.servis(this, "Sesle uyandırma açık", "“" + kelime + "” dediğinde asistan cevap verir (kilit ekranında da).");
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(2, n);
        } catch (Exception e) {
            stopSelf();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                || !SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        tanima = SpeechRecognizer.createSpeechRecognizer(this);
        tanima.setRecognitionListener(this);
        calisiyor = true;
        duraklat = MainActivity.onde;
        sonraDinle(600);
    }

    /** "asistan" + ayarlardaki uyandırma kelimesi + asistanın adı: hepsiyle çağrılabilir. */
    private void kelimeleriYukle() {
        Prefs pr = new Prefs(this);
        kelimeler.clear();
        for (String k : new String[]{ "asistan", pr.kelime(), pr.ad() }) {
            String n = norm(k);
            if (n.length() >= 3 && !kelimeler.contains(n)) kelimeler.add(n);
        }
        kelime = kelimeler.isEmpty() ? "asistan" : kelimeler.get(kelimeler.size() > 1 ? 1 : 0);
    }

    /** Metinde uyandırma kelimesi geçiyorsa, kelimeden sonrasını (soruyu) döndürür; geçmiyorsa null. */
    private String eslesme(String ham) {
        String s = " " + norm(ham) + " ";
        int en = -1, uz = 0;
        for (String k : kelimeler) {
            int i = s.indexOf(" " + k);
            if (i >= 0 && (en < 0 || i < en)) { en = i; uz = k.length() + 1; }
        }
        if (en < 0) return null;
        String kalan = s.substring(en + uz).trim();
        // "asistanım", "zeynepçim" gibi eklerin kalıntısını at
        int bosluk = kalan.indexOf(' ');
        if (!s.startsWith(" ", en + uz) && bosluk >= 0) kalan = kalan.substring(bosluk + 1).trim();
        else if (!s.startsWith(" ", en + uz)) kalan = "";
        return kalan;
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String a = i == null ? null : i.getAction();
        if (DURAKLAT.equals(a)) {
            duraklat = true;
            h.removeCallbacksAndMessages(null);
            try { if (tanima != null) tanima.cancel(); } catch (Exception ignored) {}
        } else if (DEVAM.equals(a)) {
            kelimeleriYukle();
            duraklat = false;
            sonraDinle(800);
        }
        return START_STICKY;
    }

    private void dinle() {
        if (!aktif || duraklat || tanima == null) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        try {
            tanima.startListening(i);
        } catch (Exception e) {
            sonraDinle(2000);
        }
    }

    private void sonraDinle(long ms) {
        h.removeCallbacksAndMessages(null);
        h.postDelayed(this::dinle, ms);
    }

    private String enIyi(Bundle b, boolean[] eslesti) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l == null) return null;
        for (String s : l) { String k = eslesme(s); if (k != null) { eslesti[0] = true; return k; } }
        return null;
    }

    /** Kısmi sonuç: kelime duyulduysa cümlenin kalanını yakalamak için kısa bir süre bekle. */
    private void kismiKontrol(Bundle b) {
        if (tetiklendi || (komutBekle && android.os.SystemClock.elapsedRealtime() <= komutBitis)) return;
        boolean[] e = { false };
        String k = enIyi(b, e);
        if (!e[0]) return;
        sonMetin = k;
        if (!duyuldu) {
            duyuldu = true;
            h.postDelayed(() -> { if (duyuldu && !tetiklendi) tetikle(sonMetin); }, 1400);
        }
    }

    private void sonKontrol(Bundle b) {
        if (tetiklendi) return;
        if (komutBekle && android.os.SystemClock.elapsedRealtime() > komutBitis) komutBekle = false;
        if (komutBekle) {
            ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String t = l == null || l.isEmpty() ? "" : l.get(0);
            String k = eslesme(t); if (k != null) t = k; // "Asistan durdur" tekrar söylendiyse
            if (t.trim().isEmpty()) return;
            komutBekle = false;
            String r = Kontrol.hizliKomut(this, t);
            if (r != null) { bildir(r); return; }
            tetikle(t);
            return;
        }
        boolean[] e = { false };
        String k = enIyi(b, e);
        if (e[0]) tetikle(k);
        else if (duyuldu) tetikle(sonMetin);
    }

    /** Bu dinleme oturumunu kapat (aynı cümle ikinci kez işlenmesin) ve yeniden dinle. */
    private void yenidenBasla() {
        try { if (tanima != null) tanima.cancel(); } catch (Exception ignored) {}
        sonraDinle(350);
    }

    private void bildir(String metin) {
        h.post(() -> { try { android.widget.Toast.makeText(this, metin, android.widget.Toast.LENGTH_SHORT).show(); } catch (Exception ignored) {} });
    }

    private boolean muzikCaliyor() {
        android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE);
        return am != null && am.isMusicActive();
    }

    private void bip() {
        try { new android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 70).startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 120); } catch (Exception ignored) {}
    }

    /** Kelime duyuldu: kısa komutsa (durdur, sonraki, sesi aç, fener...) uygulamayı açmadan yap; değilse asistanı aç. */
    private void tetikle(String soru) {
        if (tetiklendi) return;
        String s0 = soru == null ? "" : soru.trim();
        if (!s0.isEmpty()) {
            String r = Kontrol.hizliKomut(this, s0);
            if (r != null) { duyuldu = false; bildir(r); yenidenBasla(); return; }
        } else if (muzikCaliyor() && !MainActivity.onde) {
            // YouTube/Spotify çalarken asistanı öne getirirsek video durur: önce komutu dinle
            duyuldu = false; komutBekle = true; yenidenBasla(); bip();
            komutBitis = android.os.SystemClock.elapsedRealtime() + 8000;
            return;
        }
        ac(s0);
    }

    private void ac(String soru) {
        if (tetiklendi) return;
        tetiklendi = true;
        duyuldu = false;
        duraklat = true;
        h.removeCallbacksAndMessages(null);
        try { tanima.cancel(); } catch (Exception ignored) {}
        Intent i = new Intent(this, MainActivity.class)
                .setAction(MainActivity.ACTION_DINLE)
                .putExtra("uyandi", true)
                .putExtra("soru", soru == null ? "" : soru)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        boolean acildi = false;
        try { startActivity(i); acildi = true; } catch (Exception ignored) {}
        // Android 10+: "diğer uygulamaların üzerinde göster" izni yoksa arka plandan ekran açılamaz → tam ekran bildirim
        if (!acildi || (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(this))) Bildirim.uyandir(this, i);
        h.postDelayed(() -> {
            tetiklendi = false;
            if (!MainActivity.onde) { duraklat = false; dinle(); }
        }, 6000);
    }

    @Override public void onReadyForSpeech(Bundle b) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float db) {}
    @Override public void onBufferReceived(byte[] b) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onEvent(int t, Bundle b) {}

    @Override
    public void onPartialResults(Bundle b) { kismiKontrol(b); }

    @Override
    public void onResults(Bundle b) {
        sonKontrol(b);
        if (!tetiklendi) sonraDinle(250);
    }

    @Override
    public void onError(int e) {
        if (tetiklendi) return;
        if (duyuldu) { tetikle(sonMetin); return; }
        long bekle = e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500
                : (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? 200 : 1200;
        sonraDinle(bekle);
    }

    @Override
    public void onDestroy() {
        aktif = false;
        calisiyor = false;
        h.removeCallbacksAndMessages(null);
        if (tanima != null) { try { tanima.destroy(); } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
