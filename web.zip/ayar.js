// Firebase bağlantı bilgileri
window.FIREBASE_AYAR = {
  apiKey: "AIzaSyCFqk1MSapMLFFytiFqVWZtSVZwdglxq-k",
  authDomain: "asistan-29021.firebaseapp.com",
  projectId: "asistan-29021",
  storageBucket: "asistan-29021.firebasestorage.app",
  messagingSenderId: "170745303692",
  appId: "1:170745303692:web:669026eec3e7859b4e21a9",
  recaptchaSiteKey: ""
};
