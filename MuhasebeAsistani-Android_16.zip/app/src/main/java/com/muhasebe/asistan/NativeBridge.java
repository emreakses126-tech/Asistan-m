package com.muhasebe.asistan;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.ContactsContract;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.app.SearchManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import java.util.List;
import java.util.TimeZone;
import android.database.Cursor;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** Web uygulamasının telefonla konuştuğu köprü: window.AndroidApp */
public class NativeBridge {
    private final MainActivity act;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SpeechRecognizer tanima;
    private final Seslendirici ses;

    private final Object kilit = new Object();
    private String durum = "idle";
    private String kismi = "";
    private String hata = "";
    private final ArrayList<String> sonuclar = new ArrayList<>();
    private volatile boolean bekleyenDinle = false;

    NativeBridge(MainActivity a, WebView w) {
        act = a;
        web = w;
        ses = Seslendirici.al(a);
    }

    private volatile boolean bekleyenUyandi = false;
    private volatile String bekleyenSoru = "";

    void dinlemeIste() { dinlemeIste(false, null); }

    void dinlemeIste(boolean uyandi, String soru) {
        bekleyenUyandi = uyandi;
        bekleyenSoru = soru == null ? "" : soru;
        bekleyenDinle = true;
    }

    /** Teşhis: uygulama sürümü, arayüz kaynağı, sesle uyandırma durumu. */
    @JavascriptInterface
    public String appInfo() {
        String surum = "?";
        try { surum = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionName; } catch (Exception ignored) {}
        String kaynak = act.site() != null ? act.site().kaynak() : "?";
        boolean ust = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(act);
        boolean mik = act.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED;
        return "{\"surum\":\"" + surum + "\",\"kaynak\":\"" + kaynak + "\",\"uyandirmaAyar\":" + new Prefs(act).uyandirma()
                + ",\"uyandirmaCalisiyor\":" + WakeService.calisiyor + ",\"ustteGoster\":" + ust + ",\"mikrofon\":" + mik + "}";
    }

    @JavascriptInterface
    public void setAssistantName(String ad) { new Prefs(act).ad(ad == null ? "" : ad.trim()); }

    @JavascriptInterface
    public String phoneLocked() {
        android.app.KeyguardManager km = (android.app.KeyguardManager) act.getSystemService(android.content.Context.KEYGUARD_SERVICE);
        return km != null && km.isKeyguardLocked() ? "1" : "0";
    }

    void kapat() {
        ui.post(() -> {
            if (tanima != null) { tanima.destroy(); tanima = null; }
        });
        ses.durdur();
    }

    // ---------- genel ----------
    @JavascriptInterface
    public String version() { return "1.6"; }

    @JavascriptInterface
    public String consumeListen() {
        if (bekleyenDinle) { bekleyenDinle = false; return bekleyenUyandi ? "W:" + bekleyenSoru : "1"; }
        return "0";
    }

    @JavascriptInterface
    public void openSettings() {
        ui.post(() -> act.startActivity(new Intent(act, SettingsActivity.class)));
    }

    @JavascriptInterface
    public void openExternal(String url) {
        ui.post(() -> act.disaridaAc(Uri.parse(url)));
    }

    @JavascriptInterface
    public void vibrate() {
        ui.post(() -> {
            android.os.Vibrator v = act.getSystemService(android.os.Vibrator.class);
            if (v != null) v.vibrate(android.os.VibrationEffect.createOneShot(40, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
        });
    }

    // ---------- ses tanıma ----------
    @JavascriptInterface
    public String startListening() {
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.IZIN_MIKROFON));
            return "needperm";
        }
        if (!SpeechRecognizer.isRecognitionAvailable(act)) return "unavailable";
        synchronized (kilit) {
            sonuclar.clear();
            kismi = "";
            hata = "";
            durum = "listening";
        }
        ui.post(this::dinlemeyeBasla);
        return "ok";
    }

    private void dinlemeyeBasla() {
        if (tanima == null) {
            tanima = SpeechRecognizer.createSpeechRecognizer(act);
            tanima.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float db) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onEvent(int t, Bundle b) {}

                @Override
                public void onError(int e) {
                    synchronized (kilit) { hata = "e" + e; durum = "idle"; }
                }

                @Override
                public void onPartialResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) synchronized (kilit) { kismi = l.get(0); }
                }

                @Override
                public void onResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    synchronized (kilit) {
                        if (l != null && !l.isEmpty() && l.get(0).trim().length() > 0) sonuclar.add(l.get(0));
                        kismi = "";
                        durum = "idle";
                    }
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        try {
            tanima.cancel();
            tanima.startListening(i);
        } catch (Exception e) {
            synchronized (kilit) { durum = "idle"; hata = "start"; }
        }
    }

    @JavascriptInterface
    public void stopListening() {
        ui.post(() -> { if (tanima != null) tanima.stopListening(); });
    }

    @JavascriptInterface
    public String speechState() {
        try {
            JSONObject o = new JSONObject();
            synchronized (kilit) {
                o.put("state", durum);
                o.put("partial", kismi);
                o.put("error", hata);
                JSONArray a = new JSONArray();
                for (String s : sonuclar) a.put(s);
                o.put("finals", a);
            }
            return o.toString();
        } catch (Exception e) {
            return "{\"state\":\"idle\",\"partial\":\"\",\"error\":\"json\",\"finals\":[]}";
        }
    }

    // ---------- konuşma ----------
    @JavascriptInterface
    public String speak(String metin, double hiz) {
        return ses.konus(metin, (float) hiz) ? "ok" : "no";
    }

    @JavascriptInterface
    public boolean isSpeaking() {
        return ses.konusuyorMu();
    }

    @JavascriptInterface
    public void stopSpeaking() {
        ses.durdur();
    }

    // ---------- rehber & arama ----------
    private String bekleyenNumara = null;

    @JavascriptInterface
    public String contactsPermission() {
        return act.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED ? "granted" : "denied";
    }

    @JavascriptInterface
    public void requestContacts() {
        ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, MainActivity.IZIN_REHBER));
    }

    private static String sade(String s) {
        if (s == null) return "";
        String t = s.toLowerCase(new Locale("tr", "TR"));
        t = t.replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i').replace('ö', 'o').replace('ş', 's').replace('ü', 'u').replace("\u0307", "");
        return t.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    /** İsme göre rehberde ara: [{ad, tel, tur}] (en çok 8). Boş sorgu = ilk 400 kişi. */
    @JavascriptInterface
    public String findContacts(String sorgu) {
        if (act.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestContacts();
            return "needperm";
        }
        JSONArray sonuc = new JSONArray();
        String q = sade(sorgu);
        int sinir = q.isEmpty() ? 400 : 8;
        String[] kolon = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.TYPE};
        ArrayList<String> gorulen = new ArrayList<>();
        try (Cursor c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, kolon, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c == null) return "[]";
            ArrayList<JSONObject> tam = new ArrayList<>(), bas = new ArrayList<>(), icer = new ArrayList<>();
            while (c.moveToNext()) {
                String ad = c.getString(0), tel = c.getString(1);
                if (ad == null || tel == null) continue;
                String anahtar = ad + "|" + tel.replaceAll("[^0-9+]", "");
                if (gorulen.contains(anahtar)) continue;
                String sa = sade(ad);
                int seviye;
                if (q.isEmpty()) seviye = 3;
                else if (sa.equals(q)) seviye = 1;
                else if (sa.startsWith(q + " ") || (" " + sa + " ").contains(" " + q + " ")) seviye = 2;
                else if (sa.contains(q)) seviye = 3;
                else continue;
                gorulen.add(anahtar);
                JSONObject o = new JSONObject();
                o.put("ad", ad);
                o.put("tel", tel);
                o.put("tur", c.getInt(2) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE ? "cep" : "diger");
                (seviye == 1 ? tam : seviye == 2 ? bas : icer).add(o);
            }
            ArrayList<JSONObject> hepsi = new ArrayList<>(tam);
            hepsi.addAll(bas);
            hepsi.addAll(icer);
            for (JSONObject o : hepsi) { if (sonuc.length() >= sinir) break; sonuc.put(o); }
        } catch (Exception e) {
            return "[]";
        }
        return sonuc.toString();
    }

    /** Tüm rehber: her kişi bir kez, cep numarası öncelikli. [{ad, tel}] — izin yoksa "needperm". */
    @JavascriptInterface
    public String allContacts() {
        if (act.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestContacts();
            return "needperm";
        }
        String[] kolon = {ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.TYPE};
        java.util.LinkedHashMap<Long, String[]> kisi = new java.util.LinkedHashMap<>();
        try (Cursor c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, kolon, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c == null) return "[]";
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String ad = c.getString(1), tel = c.getString(2);
                if (ad == null || tel == null || tel.replaceAll("[^0-9]", "").length() < 7) continue;
                boolean cep = c.getInt(3) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE;
                String[] var = kisi.get(id);
                if (var == null || (cep && !"1".equals(var[2]))) kisi.put(id, new String[]{ad, tel, cep ? "1" : "0"});
            }
            JSONArray sonuc = new JSONArray();
            for (String[] k : kisi.values()) { JSONObject o = new JSONObject(); o.put("ad", k[0]); o.put("tel", k[1]); sonuc.put(o); }
            return sonuc.toString();
        } catch (Exception e) {
            return "[]";
        }
    }

    /** Numarayı direkt ara; izin yoksa izin ister, verilmezse tuşlayıcıyı açar. */
    @JavascriptInterface
    public String call(String numara) {
        if (numara == null || numara.replaceAll("[^0-9+]", "").isEmpty()) return "err";
        String temiz = numara.replaceAll("[^0-9+]", "");
        if (act.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            ui.post(() -> aramaBaslat(temiz, true));
            return "calling";
        }
        bekleyenNumara = temiz;
        ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, MainActivity.IZIN_ARAMA));
        return "needperm";
    }

    @JavascriptInterface
    public void dial(String numara) {
        String temiz = numara == null ? "" : numara.replaceAll("[^0-9+]", "");
        ui.post(() -> aramaBaslat(temiz, false));
    }

    void bekleyenAramayiBitir(boolean izinVar) {
        String n = bekleyenNumara;
        bekleyenNumara = null;
        if (n != null) aramaBaslat(n, izinVar);
    }

    private void aramaBaslat(String numara, boolean direkt) {
        try {
            Intent i = new Intent(direkt ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(numara)));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(numara)));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(i);
            } catch (Exception ignored) {
                Toast.makeText(act, "Arama başlatılamadı", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ---------- pano (Google anahtarını otomatik yakalamak için) ----------
    @JavascriptInterface
    public String getClipboard() {
        final String[] sonuc = {""};
        final java.util.concurrent.CountDownLatch bekle = new java.util.concurrent.CountDownLatch(1);
        ui.post(() -> {
            try {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(act);
                    if (t != null) sonuc[0] = t.toString();
                }
            } catch (Exception ignored) {
            }
            bekle.countDown();
        });
        try { bekle.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS); } catch (InterruptedException ignored) { }
        String t = sonuc[0] == null ? "" : sonuc[0].trim();
        return t.length() > 200 ? t.substring(0, 200) : t;
    }

    // ---------- alarm & zamanlayıcı ----------
    private boolean baslat(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** gunler: "" ya da "1,2,3" (1=Pazar ... 7=Cumartesi, java.util.Calendar) */
    @JavascriptInterface
    public String setAlarm(int saat, int dakika, String etiket, String gunler) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        i.putExtra(AlarmClock.EXTRA_HOUR, saat);
        i.putExtra(AlarmClock.EXTRA_MINUTES, dakika);
        if (etiket != null && !etiket.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, etiket);
        if (gunler != null && !gunler.trim().isEmpty()) {
            ArrayList<Integer> l = new ArrayList<>();
            for (String g : gunler.split(",")) { try { l.add(Integer.parseInt(g.trim())); } catch (Exception ignored) {} }
            if (!l.isEmpty()) i.putExtra(AlarmClock.EXTRA_DAYS, l);
        }
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        final Intent f = i;
        ui.post(() -> { if (!baslat(f)) Toast.makeText(act, "Saat uygulaması bulunamadı", Toast.LENGTH_SHORT).show(); });
        return "ok";
    }

    @JavascriptInterface
    public String setTimer(int saniye, String etiket) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
        i.putExtra(AlarmClock.EXTRA_LENGTH, saniye);
        if (etiket != null && !etiket.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, etiket);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        ui.post(() -> { if (!baslat(i)) Toast.makeText(act, "Saat uygulaması bulunamadı", Toast.LENGTH_SHORT).show(); });
        return "ok";
    }

    /** Alarmı kapat: saat>=0 ise o saatteki, değilse etikete göre, o da yoksa sıradaki alarm. */
    @JavascriptInterface
    public String dismissAlarm(int saat, int dakika, String etiket) {
        Intent i = new Intent(AlarmClock.ACTION_DISMISS_ALARM);
        if (saat >= 0) {
            i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME);
            i.putExtra(AlarmClock.EXTRA_HOUR, saat);
            i.putExtra(AlarmClock.EXTRA_MINUTES, Math.max(0, dakika));
        } else if (etiket != null && !etiket.trim().isEmpty()) {
            i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_LABEL);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, etiket);
        } else {
            i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT);
        }
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        final Intent f = i;
        ui.post(() -> { if (!baslat(f)) baslat(new Intent(AlarmClock.ACTION_SHOW_ALARMS)); });
        return "ok";
    }

    @JavascriptInterface
    public void showTimers() {
        ui.post(() -> { if (!baslat(new Intent(AlarmClock.ACTION_SHOW_TIMERS))) baslat(new Intent(AlarmClock.ACTION_SHOW_ALARMS)); });
    }

    @JavascriptInterface
    public void showAlarms() {
        ui.post(() -> baslat(new Intent(AlarmClock.ACTION_SHOW_ALARMS)));
    }

    // ---------- telefon takvimi ----------
    @JavascriptInterface
    public String calendarPermission() {
        return act.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && act.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED ? "granted" : "denied";
    }

    @JavascriptInterface
    public void requestCalendar() {
        ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR}, MainActivity.IZIN_TAKVIM));
    }

    private long takvimId() {
        String[] k = {CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.VISIBLE};
        long ilk = -1;
        try (Cursor c = act.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, k, null, null, null)) {
            if (c == null) return -1;
            while (c.moveToNext()) {
                if (c.getInt(2) < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR || c.getInt(3) == 0) continue;
                if (c.getInt(1) == 1) return c.getLong(0);
                if (ilk < 0) ilk = c.getLong(0);
            }
        } catch (Exception ignored) {
        }
        return ilk;
    }

    /** Telefon takvimine doğrudan ekler. İzin yoksa "needperm"; takvim yoksa ekleme ekranını açar ("ui"). Dönüş: etkinlik id ya da durum. */
    @JavascriptInterface
    public String addCalendarEvent(String baslik, double basla, double bitis, String yer, String aciklama, boolean tumGun, int hatirlatDk) {
        if (!"granted".equals(calendarPermission())) { requestCalendar(); return "needperm"; }
        long id = takvimId();
        if (id < 0) {
            Intent i = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, baslik)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, (long) basla)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, (long) bitis)
                    .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, tumGun)
                    .putExtra(CalendarContract.Events.EVENT_LOCATION, yer)
                    .putExtra(CalendarContract.Events.DESCRIPTION, aciklama);
            ui.post(() -> baslat(i));
            return "ui";
        }
        try {
            ContentValues v = new ContentValues();
            v.put(CalendarContract.Events.CALENDAR_ID, id);
            v.put(CalendarContract.Events.TITLE, baslik);
            v.put(CalendarContract.Events.DTSTART, (long) basla);
            v.put(CalendarContract.Events.DTEND, (long) bitis);
            v.put(CalendarContract.Events.ALL_DAY, tumGun ? 1 : 0);
            v.put(CalendarContract.Events.EVENT_TIMEZONE, tumGun ? "UTC" : TimeZone.getDefault().getID());
            if (yer != null && !yer.isEmpty()) v.put(CalendarContract.Events.EVENT_LOCATION, yer);
            if (aciklama != null && !aciklama.isEmpty()) v.put(CalendarContract.Events.DESCRIPTION, aciklama);
            Uri u = act.getContentResolver().insert(CalendarContract.Events.CONTENT_URI, v);
            if (u == null) return "err";
            long eid = Long.parseLong(u.getLastPathSegment());
            if (hatirlatDk >= 0) {
                ContentValues r = new ContentValues();
                r.put(CalendarContract.Reminders.EVENT_ID, eid);
                r.put(CalendarContract.Reminders.MINUTES, hatirlatDk);
                r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
                act.getContentResolver().insert(CalendarContract.Reminders.CONTENT_URI, r);
            }
            return String.valueOf(eid);
        } catch (Exception e) {
            return "err";
        }
    }

    @JavascriptInterface
    public String deleteCalendarEvent(String eid) {
        if (!"granted".equals(calendarPermission())) return "needperm";
        try {
            Uri u = android.content.ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(eid));
            return act.getContentResolver().delete(u, null, null) > 0 ? "ok" : "none";
        } catch (Exception e) {
            return "err";
        }
    }

    /** [{baslik, basla, bitis, yer, tumGun}] */
    @JavascriptInterface
    public String readCalendar(double bas, double son) {
        if (!"granted".equals(calendarPermission())) return "needperm";
        JSONArray a = new JSONArray();
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        android.content.ContentUris.appendId(b, (long) bas);
        android.content.ContentUris.appendId(b, (long) son);
        String[] k = {CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
                CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.VISIBLE};
        try (Cursor c = act.getContentResolver().query(b.build(), k, null, null, CalendarContract.Instances.BEGIN + " ASC")) {
            if (c == null) return "[]";
            while (c.moveToNext() && a.length() < 80) {
                if (c.getInt(5) == 0) continue;
                JSONObject o = new JSONObject();
                o.put("baslik", c.getString(0) == null ? "" : c.getString(0));
                o.put("basla", c.getLong(1));
                o.put("bitis", c.getLong(2));
                o.put("yer", c.getString(3) == null ? "" : c.getString(3));
                o.put("tumGun", c.getInt(4) == 1);
                a.put(o);
            }
        } catch (Exception e) {
            return "[]";
        }
        return a.toString();
    }

    // ---------- müzik ----------
    private boolean yuklu(String paket) {
        try { act.getPackageManager().getPackageInfo(paket, 0); return true; } catch (Exception e) { return false; }
    }

    /** tercih: "youtube" | "ytmusic" | "spotify" | "" (otomatik). Dönüş: hangi uygulamayla açıldığı.
     *  YouTube ve YouTube Music'te şarkı/video önce aranır, bulunan ilk sonuç doğrudan oynatılır (dokunmaya gerek yok). */
    @JavascriptInterface
    public String playMusic(String sorgu, String tercih) {
        final String q = sorgu == null ? "" : sorgu.trim();
        String t = tercih == null ? "" : tercih;
        boolean yt = yuklu("com.google.android.youtube"), ytm = yuklu("com.google.android.apps.youtube.music"), sp = yuklu("com.spotify.music");
        String secim;
        if ("youtube".equals(t)) secim = "youtube";
        else if ("spotify".equals(t) && sp) secim = "spotify";
        else if ("ytmusic".equals(t) && ytm) secim = "ytmusic";
        else secim = ytm ? "ytmusic" : sp ? "spotify" : "youtube";
        if (q.isEmpty()) {
            String paket = "ytmusic".equals(secim) ? "com.google.android.apps.youtube.music" : "spotify".equals(secim) ? "com.spotify.music" : "com.google.android.youtube";
            Intent i = act.getPackageManager().getLaunchIntentForPackage(paket);
            if (i != null) { final Intent f = i; ui.post(() -> baslat(f)); }
            else Kontrol.medyaTusu(act, android.view.KeyEvent.KEYCODE_MEDIA_PLAY);
            return secim;
        }
        if ("spotify".equals(secim)) {
            Intent i = new Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
            i.setPackage("com.spotify.music");
            i.putExtra(SearchManager.QUERY, q);
            i.putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
            ui.post(() -> { if (!baslat(i)) baslat(new Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q)))); });
            return "spotify";
        }
        final boolean muzik = "ytmusic".equals(secim);
        final boolean ytVar = yt;
        new Thread(() -> {
            String id = Kontrol.youtubeBul(q);
            ui.post(() -> {
                if (id != null) {
                    Intent i;
                    if (muzik) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=" + id)).setPackage("com.google.android.apps.youtube.music");
                    else if (ytVar) i = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id)).setPackage("com.google.android.youtube");
                    else i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id));
                    if (baslat(i)) return;
                    if (baslat(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id)))) return;
                }
                // bulunamadıysa: uygulamanın kendi aramasıyla dene
                if (muzik) {
                    Intent i = new Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
                    i.setPackage("com.google.android.apps.youtube.music");
                    i.putExtra(SearchManager.QUERY, q);
                    i.putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
                    if (baslat(i)) return;
                }
                Intent s2 = new Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra(SearchManager.QUERY, q);
                if (!ytVar || !baslat(s2)) baslat(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))));
            });
        }, "youtube-ara").start();
        return muzik ? "ytmusic" : "youtube";
    }

    /** Uygulamayı öne getirmeden yapılabilen komutlar: medya kontrolü, ses seviyesi, fener. Yapılamazsa "". */
    @JavascriptInterface
    public String quickCommand(String metin) {
        String r = Kontrol.hizliKomut(act, metin);
        return r == null ? "" : r;
    }

    /** Belirli bir YouTube videosunu aç (otomatik başlar). */
    @JavascriptInterface
    public void openYouTubeVideo(String videoId) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + videoId));
        if (yuklu("com.google.android.youtube")) i.setPackage("com.google.android.youtube");
        else i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + videoId));
        final Intent f = i;
        ui.post(() -> baslat(f));
    }

    // ---------- uygulama açma ----------
    private static String sadeAd(String s) { return sade(s).replace(" ", ""); }

    private static int mesafe(String a, String b) {
        int[] o = new int[b.length() + 1], y = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) o[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            y[0] = i;
            for (int j = 1; j <= b.length(); j++)
                y[j] = Math.min(Math.min(y[j - 1] + 1, o[j] + 1), o[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
            int[] t = o; o = y; y = t;
        }
        return o[b.length()];
    }

    /** Yüklü uygulamalar arasından adı en çok benzeyeni açar; "kamera", "galeri", "hesap makinesi" gibi türleri de tanır.
     *  Dönüş: açılan uygulamanın adı ya da "none". */
    @JavascriptInterface
    public String openApp(String ad) {
        String sadeAd = sade(ad).replaceAll("^(bana |hemen |bir |su |lutfen )+", "").replaceAll(" (uygulamasini|uygulamasi|uygulamayi|uygulama)$", "").trim();
        String q = Kontrol.takmaAd(sadeAd.replace(" ", ""));
        if (q.isEmpty()) return "none";
        PackageManager pm = act.getPackageManager();
        Intent ana = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> l = pm.queryIntentActivities(ana, 0);
        // Türkçe ekleri at: "instagramı", "youtube'u", "galeriyi"
        String[] adaylar = { q, q.replaceAll("(yi|yu|yı|yu|ni|nu|i|u|a|e)$", ""), q.replaceAll("(yi|yu|ni|nu|si|su)$", "") };
        ResolveInfo en = null; int puan = 0;
        for (ResolveInfo r : l) {
            String e = sadeAd(String.valueOf(r.loadLabel(pm)));
            String paket = r.activityInfo.packageName.toLowerCase(Locale.ROOT);
            if (e.isEmpty()) continue;
            for (String a : adaylar) {
                if (a.length() < 2) continue;
                int p = e.equals(a) ? 100
                        : e.startsWith(a) && a.length() >= 3 ? 80
                        : a.startsWith(e) && e.length() >= 4 ? 70
                        : (a.length() >= 4 && (e.contains(a) || paket.contains(a))) ? 60
                        : (a.length() >= 5 && mesafe(e, a) <= (a.length() >= 8 ? 2 : 1)) ? 50 : 0;
                if (p > puan) { puan = p; en = r; }
            }
        }
        if (en != null && puan >= 60) {
            Intent i = pm.getLaunchIntentForPackage(en.activityInfo.packageName);
            if (i != null) { final Intent f = i; ui.post(() -> baslat(f)); return String.valueOf(en.loadLabel(pm)); }
        }
        // ada göre yoksa türüne göre (kamera, galeri, mesajlar, hesap makinesi...)
        Intent tur = Kontrol.turIntent(sadeAd);
        if (tur != null && tur.resolveActivity(pm) != null) { final Intent f = tur; ui.post(() -> baslat(f)); return "TUR"; }
        if (en != null) {
            Intent i = pm.getLaunchIntentForPackage(en.activityInfo.packageName);
            if (i != null) { final Intent f = i; ui.post(() -> baslat(f)); return String.valueOf(en.loadLabel(pm)); }
        }
        if ("playstore".equals(q)) { Intent i = pm.getLaunchIntentForPackage("com.android.vending"); if (i != null) { ui.post(() -> baslat(i)); return "Play Store"; } }
        return "none";
    }

    /** Ayarlar ekranları: wifi, bluetooth, ses, ekran, genel */
    @JavascriptInterface
    public void openSystemSettings(String tur) {
        String a = "wifi".equals(tur) ? android.provider.Settings.ACTION_WIFI_SETTINGS
                : "bluetooth".equals(tur) ? android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                : "ses".equals(tur) ? android.provider.Settings.ACTION_SOUND_SETTINGS
                : "ekran".equals(tur) ? android.provider.Settings.ACTION_DISPLAY_SETTINGS
                : android.provider.Settings.ACTION_SETTINGS;
        ui.post(() -> baslat(new Intent(a)));
    }

    // ---------- bildirimler ----------
    @JavascriptInterface
    public void setReminders(String json) {
        Hatirlatici.planla(act.getApplicationContext(), json);
    }

    // ---------- dosya kaydetme ----------
    @JavascriptInterface
    public String saveFile(String ad, String base64) {
        try {
            byte[] veri = Base64.decode(base64, Base64.DEFAULT);
            String mime = ad.endsWith(".xlsx") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    : ad.endsWith(".csv") ? "text/csv" : "application/octet-stream";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, ad);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                ContentResolver cr = act.getContentResolver();
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return "err";
                try (OutputStream os = cr.openOutputStream(u)) {
                    if (os == null) return "err";
                    os.write(veri);
                }
            } else {
                File d = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (d == null) return "err";
                try (FileOutputStream os = new FileOutputStream(new File(d, ad))) { os.write(veri); }
            }
            ui.post(() -> Toast.makeText(act, ad + " İndirilenler'e kaydedildi", Toast.LENGTH_LONG).show());
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /** Sayfa bir blob dosyası indirmek isterse (yedek yol). */
    void blobIndir(String url, String ad) {
        String js = "(function(){fetch('" + url.replace("'", "") + "').then(function(r){return r.blob();}).then(function(b){"
                + "var f=new FileReader();f.onload=function(){AndroidApp.saveFile('" + ad.replace("'", "") + "',String(f.result).split(',')[1]);};f.readAsDataURL(b);"
                + "}).catch(function(){});})();";
        ui.post(() -> web.evaluateJavascript(js, null));
    }
}
