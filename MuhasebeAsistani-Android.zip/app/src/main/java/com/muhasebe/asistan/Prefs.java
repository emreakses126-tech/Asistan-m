package com.muhasebe.asistan;

import android.content.Context;
import android.content.SharedPreferences;

/** Uygulamanın küçük ayarları (telefonun içinde saklanır). */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("asistan", Context.MODE_PRIVATE);
    }

    public boolean ilkKurulumBitti() { return sp.getBoolean("onboarded", false); }
    public void ilkKurulumBitti(boolean v) { sp.edit().putBoolean("onboarded", v).apply(); }

    public boolean balon() { return sp.getBoolean("balon", false); }
    public void balon(boolean v) { sp.edit().putBoolean("balon", v).apply(); }

    public boolean uyandirma() { return sp.getBoolean("uyandirma", false); }
    public void uyandirma(boolean v) { sp.edit().putBoolean("uyandirma", v).apply(); }

    public String kelime() { return sp.getString("kelime", "asistan"); }
    public void kelime(String v) { sp.edit().putString("kelime", v).apply(); }

    public int balonX() { return sp.getInt("bx", -1); }
    public int balonY() { return sp.getInt("by", 300); }
    public void balonKonum(int x, int y) { sp.edit().putInt("bx", x).putInt("by", y).apply(); }

    public String hatirlatmalar() { return sp.getString("hatirlatmalar", "[]"); }
    public void hatirlatmalar(String v) { sp.edit().putString("hatirlatmalar", v).apply(); }

    public String planliKodlar() { return sp.getString("kodlar", ""); }
    public void planliKodlar(String v) { sp.edit().putString("kodlar", v).apply(); }

    public String sesKaynak() { return sp.getString("sesKaynak", "telefon"); }
    public void sesKaynak(String v) { sp.edit().putString("sesKaynak", v).apply(); }

    public String cinsiyet() { return sp.getString("cinsiyet", "kadin"); }
    public void cinsiyet(String v) { sp.edit().putString("cinsiyet", v).apply(); }

    public String elevenKey() { return sp.getString("elevenKey", ""); }
    public void elevenKey(String v) { sp.edit().putString("elevenKey", v).apply(); }

    public String elevenSes() { return sp.getString("elevenSes", "EXAVITQu4vr4xnSDxMaL"); }
    public void elevenSes(String v) { sp.edit().putString("elevenSes", v).apply(); }

    public String telefonSes() { return sp.getString("telefonSes", ""); }
    public void telefonSes(String v) { sp.edit().putString("telefonSes", v).apply(); }

    public String siradaki() { return sp.getString("siradaki", ""); }
    public void siradaki(String v) { sp.edit().putString("siradaki", v).apply(); }
}
