package com.muhasebe.asistan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Bildirim kanalları ve ortak bildirimler. */
public final class Bildirim {
    public static final String KANAL_SERVIS = "servis";
    public static final String KANAL_HATIRLATMA = "hatirlatma";

    private Bildirim() {}

    public static void kanallar(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel s = new NotificationChannel(KANAL_SERVIS, "Arka plan (yüzen balon, sesle uyandırma)", NotificationManager.IMPORTANCE_MIN);
        s.setShowBadge(false);
        nm.createNotificationChannel(s);
        NotificationChannel h = new NotificationChannel(KANAL_HATIRLATMA, "Ödeme ve fatura hatırlatmaları", NotificationManager.IMPORTANCE_HIGH);
        h.enableVibration(true);
        nm.createNotificationChannel(h);
    }

    public static PendingIntent uygulamayiAc(Context c, boolean dinle, int kod) {
        Intent i = new Intent(c, MainActivity.class);
        if (dinle) i.setAction(MainActivity.ACTION_DINLE);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, kod, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static Notification servis(Context c, String baslik, String metin) {
        kanallar(c);
        return new Notification.Builder(c, KANAL_SERVIS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(baslik)
                .setContentText(metin)
                .setOngoing(true)
                .setContentIntent(uygulamayiAc(c, true, 900))
                .build();
    }
}
