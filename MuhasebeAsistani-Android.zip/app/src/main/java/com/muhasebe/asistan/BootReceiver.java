package com.muhasebe.asistan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** Telefon yeniden başlayınca hatırlatmaları ve yüzen balonu geri kurar. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        Hatirlatici.yenidenPlanla(c);
        Prefs p = new Prefs(c);
        if (p.balon() && Settings.canDrawOverlays(c)) {
            try {
                c.startForegroundService(new Intent(c, BubbleService.class));
            } catch (Exception ignored) {
            }
        }
    }
}
