package com.muhasebe.asistan;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.Toast;

/** Diğer uygulamaların üstünde duran, sürüklenebilen canlı küre. */
public class BubbleService extends Service {
    private WindowManager wm;
    private OrbView kure;
    private WindowManager.LayoutParams lp;

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        Notification n = Bildirim.servis(this, "Yüzen asistan açık", "Küreye dokun: asistan dinlesin. Kapatmak için küreye uzun bas.");
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(1, n);
        } catch (Exception e) {
            stopSelf();
            return;
        }

        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }

        wm = getSystemService(WindowManager.class);
        kure = new OrbView(this);
        final float yog = getResources().getDisplayMetrics().density;
        final int boy = (int) (68 * yog);
        lp = new WindowManager.LayoutParams(boy, boy,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        final Prefs prefs = new Prefs(this);
        final int genislik = getResources().getDisplayMetrics().widthPixels;
        lp.x = prefs.balonX() < 0 ? genislik - boy - (int) (8 * yog) : prefs.balonX();
        lp.y = prefs.balonY();

        kure.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{e.getRawX(), e.getRawY(), lp.x, lp.y, 0f, SystemClock.uptimeMillis()});
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float[] d = (float[]) v.getTag();
                    if (d == null) return true;
                    float dx = e.getRawX() - d[0], dy = e.getRawY() - d[1];
                    if (d[4] == 0f && Math.hypot(dx, dy) > 10 * yog) d[4] = 1f;
                    if (d[4] == 1f) {
                        lp.x = (int) (d[2] + dx);
                        lp.y = (int) (d[3] + dy);
                        wm.updateViewLayout(kure, lp);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    float[] d = (float[]) v.getTag();
                    if (d == null) return true;
                    if (d[4] == 1f) {
                        lp.x = (lp.x + boy / 2 < genislik / 2) ? 0 : genislik - boy;
                        wm.updateViewLayout(kure, lp);
                        prefs.balonKonum(lp.x, lp.y);
                    } else if (SystemClock.uptimeMillis() - (long) d[5] > 650) {
                        prefs.balon(false);
                        Toast.makeText(this, "Yüzen asistan kapatıldı. Telefon ayarlarından açabilirsin.", Toast.LENGTH_LONG).show();
                        stopSelf();
                    } else {
                        ac();
                    }
                    return true;
                }
                default:
                    return false;
            }
        });
        wm.addView(kure, lp);
    }

    private void ac() {
        Intent i = new Intent(this, MainActivity.class)
                .setAction(MainActivity.ACTION_DINLE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }

    @Override
    public void onDestroy() {
        if (kure != null) {
            kure.durdur();
            try { wm.removeView(kure); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
