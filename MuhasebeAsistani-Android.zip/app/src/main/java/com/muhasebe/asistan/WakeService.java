package com.muhasebe.asistan;

import android.Manifest;
import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;

/** Uygulama kapalıyken uyandırma kelimesini dinler; duyunca asistanı açar. */
public class WakeService extends Service implements RecognitionListener {
    public static final String DURAKLAT = "com.muhasebe.asistan.DURAKLAT";
    public static final String DEVAM = "com.muhasebe.asistan.DEVAM";

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer tanima;
    private boolean aktif = true;
    private boolean duraklat = false;
    private boolean tetiklendi = false;
    private String kelime = "asistan";
    public static volatile boolean calisiyor = false;

    @Override
    public IBinder onBind(Intent i) { return null; }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(new Locale("tr", "TR")).replaceAll("[^a-z0-9çğıöşü ]", " ").replaceAll("\\s+", " ").trim();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        kelime = norm(new Prefs(this).kelime());
        if (kelime.isEmpty()) kelime = "asistan";
        Notification n = Bildirim.servis(this, "Sesle uyandırma açık", "“" + kelime + "” dediğinde asistan açılır.");
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(2, n);
        } catch (Exception e) {
            stopSelf();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                || !SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        tanima = SpeechRecognizer.createSpeechRecognizer(this);
        tanima.setRecognitionListener(this);
        calisiyor = true;
        duraklat = MainActivity.onde;
        sonraDinle(600);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String a = i == null ? null : i.getAction();
        if (DURAKLAT.equals(a)) {
            duraklat = true;
            h.removeCallbacksAndMessages(null);
            try { if (tanima != null) tanima.cancel(); } catch (Exception ignored) {}
        } else if (DEVAM.equals(a)) {
            duraklat = false;
            sonraDinle(800);
        }
        return START_STICKY;
    }

    private void dinle() {
        if (!aktif || duraklat || tanima == null) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        try {
            tanima.startListening(i);
        } catch (Exception e) {
            sonraDinle(2000);
        }
    }

    private void sonraDinle(long ms) {
        h.removeCallbacksAndMessages(null);
        h.postDelayed(this::dinle, ms);
    }

    private void kontrol(Bundle b) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (l == null) return;
        for (String s : l) {
            if (norm(s).contains(kelime)) { tetikle(); return; }
        }
    }

    private void tetikle() {
        if (tetiklendi) return;
        tetiklendi = true;
        duraklat = true;
        try { tanima.cancel(); } catch (Exception ignored) {}
        Intent i = new Intent(this, MainActivity.class)
                .setAction(MainActivity.ACTION_DINLE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { startActivity(i); } catch (Exception ignored) {}
        h.postDelayed(() -> {
            tetiklendi = false;
            if (!MainActivity.onde) { duraklat = false; dinle(); }
        }, 6000);
    }

    @Override public void onReadyForSpeech(Bundle b) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float db) {}
    @Override public void onBufferReceived(byte[] b) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onEvent(int t, Bundle b) {}

    @Override
    public void onPartialResults(Bundle b) { kontrol(b); }

    @Override
    public void onResults(Bundle b) {
        kontrol(b);
        if (!tetiklendi) sonraDinle(250);
    }

    @Override
    public void onError(int e) {
        if (tetiklendi) return;
        long bekle = e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500
                : (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? 200 : 1200;
        sonraDinle(bekle);
    }

    @Override
    public void onDestroy() {
        aktif = false;
        calisiyor = false;
        h.removeCallbacksAndMessages(null);
        if (tanima != null) { try { tanima.destroy(); } catch (Exception ignored) {} }
        super.onDestroy();
    }
}
