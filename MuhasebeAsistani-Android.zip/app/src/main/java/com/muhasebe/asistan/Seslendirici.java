package com.muhasebe.asistan;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Asistanın sesi: telefonun kendi Türkçe sesi ya da ElevenLabs. */
public final class Seslendirici {
    /** ElevenLabs hazır sesleri (çok dilli, Türkçe konuşabilir). */
    public static final String[][] KADIN = {
            {"Sarah", "EXAVITQu4vr4xnSDxMaL"}, {"Laura", "FGY2WhTYpPnrIDTdsKH5"}, {"Alice", "Xb7hH8MSUJpSbSDYk0k2"},
            {"Jessica", "cgSgspJ2msm6clMCkdW9"}, {"Matilda", "XrExE9yKIg1WjnnlVkGX"}, {"Lily", "pFZP5JQG7iQjIQuC4Bku"}};
    public static final String[][] ERKEK = {
            {"Brian", "nPczCjzI2devNBz1zQrb"}, {"George", "JBFqnCBsd6RMkjVDRZzb"}, {"Daniel", "onwK4e9ZLuTAKqWW03F9"},
            {"Liam", "TX3LPaxmHKxFdv7VOQHJ"}, {"Chris", "iP95p4xoKVk53GoZ742B"}, {"Will", "bIHbv24MWmeRgasZH58o"}};

    private static Seslendirici tek;

    public static synchronized Seslendirici al(Context c) {
        if (tek == null) tek = new Seslendirici(c.getApplicationContext());
        return tek;
    }

    private final Context c;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService is = Executors.newSingleThreadExecutor();
    private TextToSpeech tts;
    private volatile boolean hazir = false;
    private volatile boolean konusuyor = false;
    private volatile long nesil = 0;
    private MediaPlayer oynatici;
    private boolean hataGosterildi = false;

    private Seslendirici(Context c) {
        this.c = c;
        tts = new TextToSpeech(c, st -> {
            if (st != TextToSpeech.SUCCESS) return;
            int r = tts.setLanguage(new Locale("tr", "TR"));
            hazir = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            telefonSesiniUygula();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { konusuyor = true; }
                @Override public void onDone(String id) { konusuyor = false; }
                @Override public void onError(String id) { konusuyor = false; }
            });
        });
    }

    public boolean hazir() { return hazir; }

    public boolean konusuyorMu() { return konusuyor || (tts != null && tts.isSpeaking()); }

    /** Telefonda yüklü Türkçe sesler. */
    public List<Voice> turkceSesler() {
        ArrayList<Voice> l = new ArrayList<>();
        try {
            Set<Voice> s = tts.getVoices();
            if (s != null) for (Voice v : s) {
                if (v.getLocale() != null && "tr".equals(v.getLocale().getLanguage())) l.add(v);
            }
        } catch (Exception ignored) {
        }
        Collections.sort(l, (a, b) -> a.getName().compareTo(b.getName()));
        return l;
    }

    /** Sesin adından kadın/erkek tahmini (motor bildirmiyorsa boş). */
    public static String cinsiyetTahmini(Voice v) {
        String n = v.getName().toLowerCase(Locale.ROOT);
        if (n.contains("female") || n.contains("smtf") || n.contains("-f0") || n.contains("#f")) return "Kadın";
        if (n.contains("male") || n.contains("smtm") || n.contains("-m0") || n.contains("#m")) return "Erkek";
        return "";
    }

    public void telefonSesiniUygula() {
        if (tts == null) return;
        String ad = new Prefs(c).telefonSes();
        if (ad.isEmpty()) return;
        for (Voice v : turkceSesler()) {
            if (v.getName().equals(ad)) { try { tts.setVoice(v); } catch (Exception ignored) {} return; }
        }
    }

    public void durdur() {
        nesil++;
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
        ui.post(() -> {
            if (oynatici != null) {
                try { oynatici.stop(); } catch (Exception ignored) {}
                oynatici.release();
                oynatici = null;
            }
        });
        konusuyor = false;
    }

    /** Ayarlara göre konuşur; ElevenLabs olmazsa telefon sesine düşer. */
    public boolean konus(String metin, float hiz) {
        durdur();
        final long n = ++nesil;
        Prefs p = new Prefs(c);
        if ("eleven".equals(p.sesKaynak()) && !p.elevenKey().isEmpty()) {
            konusuyor = true;
            is.execute(() -> eleven(metin, p.elevenKey(), p.elevenSes(), hiz, n));
            return true;
        }
        return telefon(metin, hiz);
    }

    private boolean telefon(String metin, float hiz) {
        if (!hazir || tts == null) { konusuyor = false; return false; }
        konusuyor = true;
        tts.setSpeechRate(Math.max(0.5f, Math.min(2f, hiz)));
        tts.speak(metin, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime());
        return true;
    }

    private void eleven(String metin, String anahtar, String sesId, float hiz, long n) {
        try {
            File f = new File(c.getCacheDir(), "el_" + Integer.toHexString((sesId + "|" + hiz + "|" + metin).hashCode()) + ".mp3");
            if (!f.exists() || f.length() < 800) {
                URL u = new URL("https://api.elevenlabs.io/v1/text-to-speech/" + sesId + "?output_format=mp3_44100_64");
                HttpURLConnection h = (HttpURLConnection) u.openConnection();
                h.setRequestMethod("POST");
                h.setConnectTimeout(8000);
                h.setReadTimeout(25000);
                h.setDoOutput(true);
                h.setRequestProperty("xi-api-key", anahtar);
                h.setRequestProperty("Content-Type", "application/json");
                h.setRequestProperty("Accept", "audio/mpeg");
                JSONObject j = new JSONObject();
                j.put("text", metin);
                j.put("model_id", "eleven_flash_v2_5");
                j.put("language_code", "tr");
                JSONObject vs = new JSONObject();
                vs.put("stability", 0.5);
                vs.put("similarity_boost", 0.75);
                vs.put("speed", Math.max(0.7, Math.min(1.2, hiz)));
                j.put("voice_settings", vs);
                try (OutputStream os = h.getOutputStream()) { os.write(j.toString().getBytes(StandardCharsets.UTF_8)); }
                int kod = h.getResponseCode();
                if (kod != 200) {
                    hata(kod);
                    if (n == nesil) ui.post(() -> telefon(metin, hiz));
                    return;
                }
                try (InputStream in = h.getInputStream(); FileOutputStream fo = new FileOutputStream(f)) {
                    byte[] b = new byte[8192];
                    int r;
                    while ((r = in.read(b)) > 0) fo.write(b, 0, r);
                }
            }
            if (n != nesil) return;
            ui.post(() -> cal(f, n));
        } catch (Exception e) {
            if (n == nesil) ui.post(() -> telefon(metin, hiz));
        }
    }

    private void cal(File f, long n) {
        if (n != nesil) return;
        try {
            MediaPlayer m = new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            m.setDataSource(f.getAbsolutePath());
            m.setOnCompletionListener(x -> { konusuyor = false; x.release(); if (oynatici == x) oynatici = null; });
            m.setOnErrorListener((x, a, b) -> { konusuyor = false; return false; });
            m.prepare();
            oynatici = m;
            konusuyor = true;
            m.start();
        } catch (Exception e) {
            konusuyor = false;
        }
    }

    private void hata(int kod) {
        if (hataGosterildi) return;
        hataGosterildi = true;
        String m = kod == 401 ? "ElevenLabs anahtarı hatalı. Telefon sesine geçtim."
                : (kod == 402 || kod == 429) ? "ElevenLabs ücretsiz hakkın doldu ya da bu ses ücretli. Telefon sesine geçtim."
                : "ElevenLabs'e ulaşılamadı (" + kod + "). Telefon sesine geçtim.";
        ui.post(() -> Toast.makeText(c, m, Toast.LENGTH_LONG).show());
    }
}
