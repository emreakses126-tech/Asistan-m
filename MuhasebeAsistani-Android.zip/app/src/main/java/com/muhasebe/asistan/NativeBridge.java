package com.muhasebe.asistan;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

/** Web uygulamasının telefonla konuştuğu köprü: window.AndroidApp */
public class NativeBridge {
    private final MainActivity act;
    private final WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private SpeechRecognizer tanima;
    private final Seslendirici ses;

    private final Object kilit = new Object();
    private String durum = "idle";
    private String kismi = "";
    private String hata = "";
    private final ArrayList<String> sonuclar = new ArrayList<>();
    private volatile boolean bekleyenDinle = false;

    NativeBridge(MainActivity a, WebView w) {
        act = a;
        web = w;
        ses = Seslendirici.al(a);
    }

    void dinlemeIste() { bekleyenDinle = true; }

    void kapat() {
        ui.post(() -> {
            if (tanima != null) { tanima.destroy(); tanima = null; }
        });
        ses.durdur();
    }

    // ---------- genel ----------
    @JavascriptInterface
    public String version() { return "1.0"; }

    @JavascriptInterface
    public String consumeListen() {
        if (bekleyenDinle) { bekleyenDinle = false; return "1"; }
        return "0";
    }

    @JavascriptInterface
    public void openSettings() {
        ui.post(() -> act.startActivity(new Intent(act, SettingsActivity.class)));
    }

    @JavascriptInterface
    public void openExternal(String url) {
        ui.post(() -> act.disaridaAc(Uri.parse(url)));
    }

    @JavascriptInterface
    public void vibrate() {
        ui.post(() -> {
            android.os.Vibrator v = act.getSystemService(android.os.Vibrator.class);
            if (v != null) v.vibrate(android.os.VibrationEffect.createOneShot(40, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
        });
    }

    // ---------- ses tanıma ----------
    @JavascriptInterface
    public String startListening() {
        if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ui.post(() -> act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.IZIN_MIKROFON));
            return "needperm";
        }
        if (!SpeechRecognizer.isRecognitionAvailable(act)) return "unavailable";
        synchronized (kilit) {
            sonuclar.clear();
            kismi = "";
            hata = "";
            durum = "listening";
        }
        ui.post(this::dinlemeyeBasla);
        return "ok";
    }

    private void dinlemeyeBasla() {
        if (tanima == null) {
            tanima = SpeechRecognizer.createSpeechRecognizer(act);
            tanima.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float db) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onEvent(int t, Bundle b) {}

                @Override
                public void onError(int e) {
                    synchronized (kilit) { hata = "e" + e; durum = "idle"; }
                }

                @Override
                public void onPartialResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) synchronized (kilit) { kismi = l.get(0); }
                }

                @Override
                public void onResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    synchronized (kilit) {
                        if (l != null && !l.isEmpty() && l.get(0).trim().length() > 0) sonuclar.add(l.get(0));
                        kismi = "";
                        durum = "idle";
                    }
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        try {
            tanima.cancel();
            tanima.startListening(i);
        } catch (Exception e) {
            synchronized (kilit) { durum = "idle"; hata = "start"; }
        }
    }

    @JavascriptInterface
    public void stopListening() {
        ui.post(() -> { if (tanima != null) tanima.stopListening(); });
    }

    @JavascriptInterface
    public String speechState() {
        try {
            JSONObject o = new JSONObject();
            synchronized (kilit) {
                o.put("state", durum);
                o.put("partial", kismi);
                o.put("error", hata);
                JSONArray a = new JSONArray();
                for (String s : sonuclar) a.put(s);
                o.put("finals", a);
            }
            return o.toString();
        } catch (Exception e) {
            return "{\"state\":\"idle\",\"partial\":\"\",\"error\":\"json\",\"finals\":[]}";
        }
    }

    // ---------- konuşma ----------
    @JavascriptInterface
    public String speak(String metin, double hiz) {
        return ses.konus(metin, (float) hiz) ? "ok" : "no";
    }

    @JavascriptInterface
    public boolean isSpeaking() {
        return ses.konusuyorMu();
    }

    @JavascriptInterface
    public void stopSpeaking() {
        ses.durdur();
    }

    // ---------- bildirimler ----------
    @JavascriptInterface
    public void setReminders(String json) {
        Hatirlatici.planla(act.getApplicationContext(), json);
    }

    // ---------- dosya kaydetme ----------
    @JavascriptInterface
    public String saveFile(String ad, String base64) {
        try {
            byte[] veri = Base64.decode(base64, Base64.DEFAULT);
            String mime = ad.endsWith(".xlsx") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    : ad.endsWith(".csv") ? "text/csv" : "application/octet-stream";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, ad);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                ContentResolver cr = act.getContentResolver();
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return "err";
                try (OutputStream os = cr.openOutputStream(u)) {
                    if (os == null) return "err";
                    os.write(veri);
                }
            } else {
                File d = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (d == null) return "err";
                try (FileOutputStream os = new FileOutputStream(new File(d, ad))) { os.write(veri); }
            }
            ui.post(() -> Toast.makeText(act, ad + " İndirilenler'e kaydedildi", Toast.LENGTH_LONG).show());
            return "ok";
        } catch (Exception e) {
            return "err";
        }
    }

    /** Sayfa bir blob dosyası indirmek isterse (yedek yol). */
    void blobIndir(String url, String ad) {
        String js = "(function(){fetch('" + url.replace("'", "") + "').then(function(r){return r.blob();}).then(function(b){"
                + "var f=new FileReader();f.onload=function(){AndroidApp.saveFile('" + ad.replace("'", "") + "',String(f.result).split(',')[1]);};f.readAsDataURL(b);"
                + "}).catch(function(){});})();";
        ui.post(() -> web.evaluateJavascript(js, null));
    }
}
