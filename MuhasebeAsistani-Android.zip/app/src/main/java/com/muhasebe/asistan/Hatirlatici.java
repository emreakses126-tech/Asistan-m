package com.muhasebe.asistan;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Web uygulamasından gelen hatırlatmaları telefon alarmlarına çevirir. */
public final class Hatirlatici {
    private Hatirlatici() {}

    /** json: [{"id":"..","title":"..","text":"..","at":epochMillis}, ...] */
    public static synchronized void planla(Context c, String json) {
        Prefs prefs = new Prefs(c);
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;

        String eski = prefs.planliKodlar();
        if (!eski.isEmpty()) {
            for (String k : eski.split(",")) {
                try {
                    int kod = Integer.parseInt(k);
                    PendingIntent pi = PendingIntent.getBroadcast(c, kod, new Intent(c, ReminderReceiver.class),
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) { am.cancel(pi); pi.cancel(); }
                } catch (Exception ignored) {
                }
            }
        }

        StringBuilder kodlar = new StringBuilder();
        long simdi = System.currentTimeMillis();
        long enYakin = Long.MAX_VALUE;
        String enYakinMetin = "";
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length() && i < 60; i++) {
                JSONObject o = a.getJSONObject(i);
                long zaman = o.optLong("at", 0);
                if (zaman <= simdi) continue;
                String id = o.optString("id", "x" + i);
                String baslik = o.optString("title", "Hatırlatma");
                String metin = o.optString("text", "");
                int kod = (id.hashCode() & 0x7fffffff) % 1000000 + 1000;
                Intent in = new Intent(c, ReminderReceiver.class)
                        .putExtra("id", id).putExtra("title", baslik).putExtra("text", metin).putExtra("kod", kod);
                PendingIntent pi = PendingIntent.getBroadcast(c, kod, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, zaman, pi);
                if (kodlar.length() > 0) kodlar.append(',');
                kodlar.append(kod);
                if (zaman < enYakin) { enYakin = zaman; enYakinMetin = baslik; }
            }
            prefs.hatirlatmalar(json);
        } catch (Exception ignored) {
        }
        prefs.planliKodlar(kodlar.toString());

        if (enYakin != Long.MAX_VALUE) {
            String gun = new SimpleDateFormat("d MMM HH:mm", new Locale("tr", "TR")).format(new Date(enYakin));
            prefs.siradaki("Sıradaki: " + enYakinMetin + " · " + gun);
        } else {
            prefs.siradaki("");
        }
        AsistanWidget.guncelle(c);
    }

    public static void yenidenPlanla(Context c) {
        planla(c, new Prefs(c).hatirlatmalar());
    }
}
