package com.muhasebe.asistan;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Zamanı gelen hatırlatmayı bildirim olarak gösterir. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Bildirim.kanallar(c);
        String baslik = i.getStringExtra("title");
        String metin = i.getStringExtra("text");
        int kod = i.getIntExtra("kod", 1);
        Notification n = new Notification.Builder(c, Bildirim.KANAL_HATIRLATMA)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(baslik == null ? "Hatırlatma" : baslik)
                .setContentText(metin == null ? "" : metin)
                .setStyle(new Notification.BigTextStyle().bigText(metin == null ? "" : metin))
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(Bildirim.uygulamayiAc(c, false, kod))
                .build();
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        try {
            if (nm != null) nm.notify(kod, n);
        } catch (SecurityException ignored) {
        }
        AsistanWidget.guncelle(c);
    }
}
