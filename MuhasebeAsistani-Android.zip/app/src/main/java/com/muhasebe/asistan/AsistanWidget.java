package com.muhasebe.asistan;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;

/** Ana ekran widget'ı: dokununca asistan açılır ve dinler; sıradaki hatırlatmayı gösterir. */
public class AsistanWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] idler) {
        guncelle(c);
    }

    public static void guncelle(Context c) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            ComponentName cn = new ComponentName(c, AsistanWidget.class);
            int[] idler = m.getAppWidgetIds(cn);
            if (idler == null || idler.length == 0) return;
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
            String s = new Prefs(c).siradaki();
            rv.setTextViewText(R.id.w_alt, s.isEmpty() ? c.getString(R.string.widget_alt) : s);
            rv.setOnClickPendingIntent(R.id.w_kok, Bildirim.uygulamayiAc(c, true, 700));
            m.updateAppWidget(cn, rv);
        } catch (Exception ignored) {
        }
    }
}
