# Muhasebe Asistanı — Android uygulaması

Bu klasör, telefonuna kurulacak **APK** dosyasının kaynağıdır. APK'yı GitHub senin yerine bulutta, ücretsiz olarak üretir. Bilgisayar gerekmez.

## APK'yı almak (yaklaşık 10 dakika)

1. **github.com** adresinden ücretsiz hesap aç (zaten varsa giriş yap).
2. Sağ üstteki **+** → **New repository** → ad: `muhasebe-asistani` → **Private** seç → **Create repository**.
3. Açılan sayfada **uploading an existing file** bağlantısına dokun.
4. Bu zip'i aç ve **içindeki her şeyi** (app klasörü, .github klasörü ve diğer dosyalar) sürükleyip bırak → **Commit changes**.
   - Telefondan yüklüyorsan klasörler bozulabilir. Bu adımı bir bilgisayardan ya da tabletten yapmak en kolayı.
   - `.github` klasörü gizli görünebilir; yüklendiğinden emin ol. APK'yı o üretir.
5. Üstteki **Actions** sekmesine geç. "APK oluştur" yaklaşık 5 dakika çalışır; yeşil tik görünce hazırdır.
6. Depo ana sayfasında sağdaki **Releases** → en üstteki sürüm → **MuhasebeAsistani.apk**'ya telefonundan dokun ve indir.
7. İndirilen dosyaya dokun → "Bilinmeyen kaynaklardan yükleme" izni sorarsa **izin ver** → **Yükle**.

Kırmızı çarpı çıkarsa Actions'taki hata sayfasının ekran görüntüsünü ya da metnini Claude'a gönder, düzeltilmiş dosyayı hazırlasın.

## İlk açılış

- Uygulama "Hoş geldin" ekranıyla açılır: mikrofon, bildirim ve "diğer uygulamaların üstünde göster" izinlerini tek tek ver.
- Sonra Claude hesabınla giriş yap. **E-posta ile giriş** önerilir; Google ile giriş uygulama içinde engellenebilir.
- Verilerin web sürümüyle aynıdır: telefonda, bilgisayarda ve uygulamada hepsi eşit kalır.

## Özellikler

| Özellik | Nasıl |
|---|---|
| Yüzen küre | Telefon ayarları → "Yüzen asistanı göster". Dokun: dinler. Sürükle: taşı. Uzun bas: kapat. |
| Ana ekran widget'ı | Telefon ayarları → "Ana ekrana widget ekle". Sıradaki hatırlatmayı gösterir, dokununca dinler. |
| Sesle açılma | Telefon ayarları → "Uyandırma kelimesiyle aç" (asistanının adını yaz). Ayrıca "Hey Google, Muhasebe Asistanı aç". |
| Bildirimler | Fatura son günleri, söz günleri, borç günleri ve randevular kendiliğinden telefona bildirim olarak gelir. |
| Konuşma | Küreye dokun, doğrudan konuş — klavye gerekmez (telefonun Türkçe ses tanıması). |
| Asistanın sesi | Telefon ayarları → "Asistanın sesi": Kadın / Erkek. Telefonun kendi sesi (ücretsiz, sınırsız) ya da ElevenLabs (çok gerçekçi; ücretsiz hesapla ayda yaklaşık 10.000 kredi, hak bitince telefon sesine geçer). |
| Excel | Ayarlar → Excel'e aktar → dosya **İndirilenler** klasörüne kaydedilir. |
| Kısayol | Uygulama simgesine basılı tut → "Konuş". |

## Bilmen gerekenler

- Sesle uyandırma pil harcar. Bazı telefonlar her dinlemede kısa bir "bip" sesi çıkarabilir; rahatsız ederse kapat.
- Bazı telefonlar (Xiaomi, Huawei, Oppo vb.) arka plandaki uygulamaları kapatır. Yüzen küre kaybolursa: Ayarlar → Uygulamalar → Muhasebe Asistanı → Pil → **Kısıtlama yok**.
- Uygulamanın adı `app/src/main/res/values/strings.xml` dosyasındaki `app_name` satırından değiştirilebilir.
