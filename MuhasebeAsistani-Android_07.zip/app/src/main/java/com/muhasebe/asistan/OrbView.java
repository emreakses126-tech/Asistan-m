package com.muhasebe.asistan;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Sürekli dönen, nefes alan canlı küre. */
public class OrbView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path yol = new Path();
    private final RectF kutu = new RectF();
    private final long t0 = SystemClock.uptimeMillis();
    private final int[] renk = {0xFF1F5BFF, 0xFF4DA3FF, 0xFF8FC0FF};
    private boolean calis = true;
    private float enerji = 0.35f;

    public OrbView(Context c) {
        super(c);
    }

    public void enerji(float e) { enerji = e; }

    public void durdur() { calis = false; }

    private static int alfa(int renk, int a) {
        return (renk & 0x00FFFFFF) | (a << 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float R = Math.min(w, h) / 2f, cx = w / 2f, cy = h / 2f;
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        float base = R * 0.46f * (1f + 0.04f * (float) Math.sin(t * 1.6));
        p.setStyle(Paint.Style.FILL);

        p.setShader(new RadialGradient(cx, cy, R, new int[]{0x881F5BFF, 0x334DA3FF, 0x00000000}, new float[]{0.25f, 0.7f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R, p);

        for (int li = 0; li < 3; li++) {
            float dir = li == 1 ? -1.25f : (li == 2 ? 0.8f : 1f);
            float ph = li * 2.1f;
            yol.reset();
            int N = 48;
            double rot = t * 0.35 * dir;
            for (int i = 0; i <= N; i++) {
                double a = i * 2 * Math.PI / N;
                double n = Math.sin(a * 3 + t * 1.3 * dir + ph) * 0.5 + Math.sin(a * 5 - t * 1.9 + ph * 1.7) * 0.3 + Math.sin(a * 2 + t * 0.7 + li) * 0.45;
                float r = (float) (base * (1 + n * 0.1 * (0.45 + enerji)));
                float x = (float) (cx + Math.cos(a + rot) * r);
                float y = (float) (cy + Math.sin(a + rot) * r);
                if (i == 0) yol.moveTo(x, y); else yol.lineTo(x, y);
            }
            yol.close();
            float ox = (float) Math.cos(t * 0.6 * dir + ph) * base * 0.25f;
            float oy = (float) Math.sin(t * 0.5 * dir + ph) * base * 0.25f;
            p.setShader(new RadialGradient(cx + ox, cy + oy, base * 1.2f,
                    new int[]{alfa(renk[li], 190), alfa(renk[li], 90), alfa(renk[li], 10)},
                    new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP));
            c.drawPath(yol, p);
        }

        p.setShader(new RadialGradient(cx - base * 0.35f, cy - base * 0.45f, base * 0.9f, 0x70FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, base * 0.98f, p);

        float k = base * (0.18f + 0.04f * (float) Math.sin(t * 2.2));
        p.setShader(new RadialGradient(cx, cy, k * 1.6f, 0xE6FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, k * 1.6f, p);
        p.setShader(null);

        // beyaz neon halkalar: dönen ve nefes alan
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        float[][][] parca = {{{0f, 132f}, {172f, 320f}}, {{0f, 63f}, {92f, 223f}, {258f, 320f}}, {{0f, 235f}}};
        for (int i = 0; i < 3; i++) {
            float rr = base * (1.24f + i * 0.2f) * (1f + 0.05f * (float) Math.sin(t * 1.15 - i * 0.9) + 0.04f * enerji);
            if (rr > R * 0.97f) continue;
            float yon = i == 1 ? -1f : 1f;
            float don = (float) Math.toDegrees(t * (0.55f - i * 0.12f) * yon + i * 1.7f);
            float al = (0.5f + 0.3f * (0.5f + 0.5f * (float) Math.sin(t * 1.15 - i * 0.9))) * (1f - i * 0.18f) + 0.2f * enerji;
            kutu.set(cx - rr, cy - rr, cx + rr, cy + rr);
            for (float[] pr : parca[i]) {
                p.setStrokeWidth(Math.max(3f, R * 0.06f)); p.setColor(alfa(renk[0], (int) Math.min(255, 46 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
                p.setStrokeWidth(Math.max(2f, R * 0.028f)); p.setColor(alfa(0xFFFFFFFF, (int) Math.min(255, 40 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
                p.setStrokeWidth(Math.max(1f, R * 0.01f)); p.setColor(alfa(0xFFFFFFFF, (int) Math.min(255, 230 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
            }
        }
        p.setStyle(Paint.Style.FILL);

        if (calis) postInvalidateOnAnimation();
    }
}
