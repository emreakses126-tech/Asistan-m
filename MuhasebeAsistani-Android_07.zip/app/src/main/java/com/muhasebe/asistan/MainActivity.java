package com.muhasebe.asistan;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

/** Ana ekran: asistan uygulamasını tam ekran açar ve telefon özelliklerini ona bağlar. */
public class MainActivity extends Activity {
    public static final String ADRES = "https://emreakses126-tech.github.io/Asistan-m/";
    public static final String ACTION_DINLE = "com.muhasebe.asistan.DINLE";
    static final int IZIN_MIKROFON = 11;
    static final int IZIN_REHBER = 12;
    static final int IZIN_ARAMA = 13;
    static final int IZIN_TAKVIM = 14;
    public static volatile boolean onde = false;

    private WebView web;
    private OrbView yukleniyor;
    private NativeBridge kopru;
    private PermissionRequest bekleyenIzin;

    @Override
    protected void onCreate(Bundle kayit) {
        super.onCreate(kayit);
        Bildirim.kanallar(this);
        Prefs prefs = new Prefs(this);

        FrameLayout kok = new FrameLayout(this);
        kok.setBackgroundColor(0xFF000000);
        web = new WebView(this);
        kok.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        yukleniyor = new OrbView(this);
        int boy = (int) (170 * getResources().getDisplayMetrics().density);
        kok.addView(yukleniyor, new FrameLayout.LayoutParams(boy, boy, Gravity.CENTER));
        setContentView(kok);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setUserAgentString(s.getUserAgentString() + " MuhasebeAsistani/1.0");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        kopru = new NativeBridge(this, web);
        web.addJavascriptInterface(kopru, "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                if (icerde(u)) return false;
                disaridaAc(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                yukleniyor.durdur();
                yukleniyor.setVisibility(View.GONE);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest istek) {
                runOnUiThread(() -> {
                    boolean ses = false;
                    for (String k : istek.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(k)) ses = true;
                    }
                    if (!ses) { istek.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        istek.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        bekleyenIzin = istek;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, IZIN_MIKROFON);
                    }
                });
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean diyalog, boolean kullanici, Message sonuc) {
                WebView gecici = new WebView(MainActivity.this);
                gecici.setWebViewClient(new WebViewClient() {
                    boolean bitti = false;

                    private void yonlendir(WebView w, Uri u) {
                        if (bitti || u == null) return;
                        bitti = true;
                        if (icerde(u)) web.loadUrl(u.toString()); else disaridaAc(u);
                        w.post(w::destroy);
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) {
                        yonlendir(w, r.getUrl());
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView w, String url, Bitmap ikon) {
                        if (url != null && !url.equals("about:blank")) yonlendir(w, Uri.parse(url));
                    }
                });
                WebView.WebViewTransport tasiyici = (WebView.WebViewTransport) sonuc.obj;
                tasiyici.setWebView(gecici);
                sonuc.sendToTarget();
                return true;
            }
        });

        web.setDownloadListener((url, ua, aciklama, mime, boyut) -> {
            if (url.startsWith("blob:")) kopru.blobIndir(url, URLUtil.guessFileName(url, aciklama, mime));
            else if (url.startsWith("data:")) Toast.makeText(this, "Bu dosya türü indirilemedi", Toast.LENGTH_SHORT).show();
            else disaridaAc(Uri.parse(url));
        });

        if (kayit != null) web.restoreState(kayit);
        else web.loadUrl(ADRES);
        dinlemeIstegi(getIntent());

        if (!prefs.ilkKurulumBitti()) {
            startActivity(new Intent(this, SettingsActivity.class).putExtra("ilk", true));
        }
    }

    static boolean icerde(Uri u) {
        if (u == null) return false;
        String sema = u.getScheme();
        String host = u.getHost();
        if (!"https".equals(sema) || host == null) return false;
        return host.equals("emreakses126-tech.github.io") || host.endsWith(".firebaseapp.com") || host.endsWith(".web.app")
                || host.equals("claude.ai") || host.endsWith(".claude.ai")
                || host.endsWith(".anthropic.com") || host.equals("anthropic.com")
                || host.endsWith("claudeusercontent.com")
                || host.equals("accounts.google.com") || host.equals("appleid.apple.com");
    }

    void disaridaAc(Uri u) {
        try {
            Intent i;
            if ("intent".equals(u.getScheme())) {
                i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
            } else {
                i = new Intent(Intent.ACTION_VIEW, u);
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Bunu açacak uygulama bulunamadı", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Bağlantı açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    private void dinlemeIstegi(Intent i) {
        if (i != null && ACTION_DINLE.equals(i.getAction())) kopru.dinlemeIste();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        dinlemeIstegi(i);
    }

    @Override
    public void onRequestPermissionsResult(int kod, String[] izinler, int[] sonuclar) {
        super.onRequestPermissionsResult(kod, izinler, sonuclar);
        if (kod == IZIN_MIKROFON) {
            boolean verildi = sonuclar.length > 0 && sonuclar[0] == PackageManager.PERMISSION_GRANTED;
            if (bekleyenIzin != null) {
                if (verildi) bekleyenIzin.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                else bekleyenIzin.deny();
                bekleyenIzin = null;
            }
            if (verildi) Toast.makeText(this, "Mikrofon izni verildi. Tekrar dokun ve konuş.", Toast.LENGTH_SHORT).show();
        } else if (kod == IZIN_REHBER || kod == IZIN_ARAMA || kod == IZIN_TAKVIM) {
            boolean verildi = sonuclar.length > 0 && sonuclar[0] == PackageManager.PERMISSION_GRANTED;
            String olay = kod == IZIN_REHBER ? "rehber" : kod == IZIN_ARAMA ? "arama" : "takvim";
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('androidIzin',{detail:{izin:'" + olay + "',verildi:" + verildi + "}}))", null);
            if (kod == IZIN_ARAMA && kopru != null) kopru.bekleyenAramayiBitir(verildi);
        }
    }

    private void uyandirmaServisi(String eylem) {
        if (!WakeService.calisiyor) return;
        try {
            startService(new Intent(this, WakeService.class).setAction(eylem));
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        onde = true;
        web.onResume();
        uyandirmaServisi(WakeService.DURAKLAT);
    }

    @Override
    protected void onPause() {
        onde = false;
        uyandirmaServisi(WakeService.DEVAM);
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle kayit) {
        super.onSaveInstanceState(kayit);
        web.saveState(kayit);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        kopru.kapat();
        web.destroy();
        super.onDestroy();
    }
}
