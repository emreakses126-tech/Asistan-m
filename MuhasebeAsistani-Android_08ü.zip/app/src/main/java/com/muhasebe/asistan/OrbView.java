package com.muhasebe.asistan;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Organik, nefes alan canlı küre: dalgalanan zar, içte plazma lifleri, dönen neon halkalar. */
public class OrbView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path zar = new Path();
    private final Path lif = new Path();
    private final RectF kutu = new RectF();
    private final long t0 = SystemClock.uptimeMillis();
    // elektrik mavisi paleti: koyu ana renk, orta, açık
    private final int[] renk = {0xFF1F5BFF, 0xFF4DA3FF, 0xFF8FC0FF};
    private final float[][] tane = new float[10][3];
    private boolean calis = true;
    private float enerji = 0.35f;

    public OrbView(Context c) {
        super(c);
        for (int i = 0; i < tane.length; i++) {
            tane[i][0] = (float) (Math.random() * Math.PI * 2);
            tane[i][1] = (float) ((0.25 + Math.random() * 0.6) * (Math.random() < 0.5 ? -1 : 1));
            tane[i][2] = (float) Math.random();
        }
    }

    public void enerji(float e) { enerji = e; }

    public void durdur() { calis = false; }

    private static int alfa(int renk, int a) {
        return (renk & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    private static int karart(int renk, float k) {
        int r = (int) (((renk >> 16) & 255) * k), g = (int) (((renk >> 8) & 255) * k), b = (int) ((renk & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void zarYap(float cx, float cy, float base, float t, float e) {
        zar.reset();
        int N = 64;
        double rot = t * 0.18;
        for (int i = 0; i <= N; i++) {
            double a = i * 2 * Math.PI / N;
            double n = Math.sin(a * 3 + t * 1.1) * 0.45 + Math.sin(a * 5 - t * 1.6 + 1.3) * 0.28
                    + Math.sin(a * 2 + t * 0.6 + 2.1) * 0.4 + Math.sin(a * 7 + t * 2.3) * 0.12 * e;
            float r = (float) (base * (1 + n * 0.045 * (0.6 + e)));
            float x = (float) (cx + Math.cos(a + rot) * r), y = (float) (cy + Math.sin(a + rot) * r);
            if (i == 0) zar.moveTo(x, y); else zar.lineTo(x, y);
        }
        zar.close();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float R = Math.min(w, h) / 2f, cx = w / 2f, cy = h / 2f;
        float t = (SystemClock.uptimeMillis() - t0) / 1000f;
        float e = enerji;
        float base = R * 0.44f * (1f + 0.04f * (float) Math.sin(t * 1.6) + 0.05f * e);
        p.setStyle(Paint.Style.FILL);
        p.setXfermode(null);

        // dış ışıma
        p.setShader(new RadialGradient(cx, cy, base * 1.95f,
                new int[]{alfa(renk[0], (int) (90 + 36 * e)), alfa(renk[1], 26), 0x00000000},
                new float[]{0.35f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, base * 1.95f, p);

        // gövde
        zarYap(cx, cy, base, t, e);
        int koyu = karart(renk[0], 0.16f), orta = karart(renk[0], 0.55f);
        p.setShader(new RadialGradient(cx - base * 0.28f, cy - base * 0.34f, base * 1.08f,
                new int[]{alfa(renk[2], 242), alfa(renk[1], 235), alfa(renk[0], 245), orta, koyu},
                new float[]{0f, 0.3f, 0.62f, 0.88f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(zar, p);

        // içerik: zarın içine kırpılmış plazma lifleri ve ışık kütleleri
        c.save();
        c.clipPath(zar);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int k = 0; k < 7; k++) {
            double th = t * (0.22 + k * 0.03) * (k % 2 == 1 ? -1 : 1) + k * 0.9;
            double ct = Math.cos(th), st = Math.sin(th);
            double amp = base * (0.18 + 0.1 * Math.sin(t * 0.7 + k)) * (0.7 + e * 0.6);
            lif.reset();
            for (int j = 0; j <= 22; j++) {
                double u = j / 22.0 * 2 - 1, px = u * base * 1.15;
                double py = Math.sin(u * 3.1 + t * 1.4 + k * 1.7) * amp * Math.cos(u * 1.4) + (k - 3) * base * 0.07;
                float x = (float) (cx + px * ct - py * st), y = (float) (cy + px * st + py * ct);
                if (j == 0) lif.moveTo(x, y); else lif.lineTo(x, y);
            }
            float al = (0.2f + 0.22f * (0.5f + 0.5f * (float) Math.sin(t * 1.3 + k * 2))) * (0.75f + e * 0.5f);
            p.setColor(alfa(k % 3 == 0 ? 0xFFEBF4FF : renk[1 + (k % 2)], (int) (255 * al)));
            p.setStrokeWidth(Math.max(1f, R * (0.008f + (k % 3) * 0.004f)));
            c.drawPath(lif, p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int li = 0; li < 2; li++) {
            float ph = li * 3.1f, yon = li == 1 ? -1f : 1f;
            float ox = (float) Math.cos(t * 0.5f * yon + ph) * base * 0.35f, oy = (float) Math.sin(t * 0.42f * yon + ph) * base * 0.35f;
            p.setShader(new RadialGradient(cx + ox, cy + oy, base * 0.75f, alfa(renk[1 + li], (int) (95 + 50 * e)), 0x00000000, Shader.TileMode.CLAMP));
            c.drawCircle(cx + ox, cy + oy, base * 0.75f, p);
        }
        // kenar gölgesi: hacim hissi
        p.setShader(new RadialGradient(cx, cy, base * 1.06f, new int[]{0x00000000, 0x00000000, alfa(koyu, 180)}, new float[]{0f, 0.52f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, base * 1.1f, p);
        c.restore();

        // zar kenar ışığı
        p.setStyle(Paint.Style.STROKE);
        p.setShader(null);
        p.setColor(alfa(renk[0], (int) (90 + 50 * e)));
        p.setStrokeWidth(Math.max(2f, R * 0.04f));
        c.drawPath(zar, p);
        p.setShader(new LinearGradient(cx - base, cy - base, cx + base, cy + base,
                new int[]{0xE6FFFFFF, alfa(renk[1], 140), alfa(renk[2], 215)}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        p.setStrokeWidth(Math.max(1.2f, R * 0.012f));
        c.drawPath(zar, p);
        p.setShader(null);

        // yörüngedeki ışık tanecikleri
        p.setStyle(Paint.Style.FILL);
        for (float[] tn : tane) {
            tn[0] += tn[1] * 0.012f * (0.5f + e * 1.6f);
            float rr = base * (0.78f + tn[2] * 0.38f) * 1.16f;
            float x = (float) (cx + Math.cos(tn[0]) * rr), y = (float) (cy + Math.sin(tn[0]) * rr * (0.82f + 0.18f * Math.sin(tn[2] * 5 + t * 0.3)));
            p.setColor(alfa(renk[(int) (tn[2] * 2.99f)], (int) (255 * (0.5f + 0.4f * (float) Math.sin(t * 2 + tn[2] * 9)))));
            c.drawCircle(x, y, Math.max(1f, R * 0.012f * (0.6f + tn[2])), p);
        }

        // keskin parlama noktası
        float sx = cx - base * 0.36f, sy = cy - base * 0.42f;
        p.setShader(new RadialGradient(sx, sy, base * 0.3f, new int[]{0xBFFFFFFF, 0x2EFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        c.save();
        c.rotate(-40, sx, sy);
        kutu.set(sx - base * 0.3f, sy - base * 0.2f, sx + base * 0.3f, sy + base * 0.2f);
        c.drawOval(kutu, p);
        c.restore();

        // nabız gibi atan çekirdek
        float k = base * (0.11f + 0.07f * e + 0.03f * (float) Math.sin(t * 2.2));
        p.setShader(new RadialGradient(cx, cy, k * 1.6f, new int[]{0xE6FFFFFF, 0x59FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, k * 1.6f, p);
        p.setShader(null);

        // beyaz neon halkalar: dönen ve nefes alan
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        float[][][] parca = {{{0f, 132f}, {172f, 320f}}, {{0f, 63f}, {92f, 223f}, {258f, 320f}}, {{0f, 235f}}};
        for (int i = 0; i < 3; i++) {
            float rr = base * (1.24f + i * 0.2f) * (1f + 0.05f * (float) Math.sin(t * 1.15 - i * 0.9) + 0.04f * e);
            if (rr > R * 0.97f) continue;
            float yon = i == 1 ? -1f : 1f;
            float don = (float) Math.toDegrees(t * (0.55f - i * 0.12f) * yon + i * 1.7f);
            float al = (0.5f + 0.3f * (0.5f + 0.5f * (float) Math.sin(t * 1.15 - i * 0.9))) * (1f - i * 0.18f) + 0.2f * e;
            kutu.set(cx - rr, cy - rr, cx + rr, cy + rr);
            for (float[] pr : parca[i]) {
                p.setStrokeWidth(Math.max(3f, R * 0.06f)); p.setColor(alfa(renk[0], (int) (46 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
                p.setStrokeWidth(Math.max(2f, R * 0.028f)); p.setColor(alfa(0xFFFFFFFF, (int) (40 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
                p.setStrokeWidth(Math.max(1f, R * 0.01f)); p.setColor(alfa(0xFFFFFFFF, (int) (230 * al)));
                c.drawArc(kutu, don + pr[0], pr[1] - pr[0], false, p);
            }
        }
        p.setStyle(Paint.Style.FILL);

        if (calis) postInvalidateOnAnimation();
    }
}
