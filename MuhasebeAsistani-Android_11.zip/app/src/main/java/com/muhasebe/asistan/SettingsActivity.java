package com.muhasebe.asistan;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Telefon özellikleri: izinler, yüzen balon, sesle uyandırma, widget. Büyük ve sade. */
public class SettingsActivity extends Activity {
    private static final int IZIN_MIK = 21, IZIN_BILDIRIM = 22;
    private Prefs prefs;
    private float yog;
    private TextView mikDurum, bildirimDurum, ustDurum;
    private Switch balonSw, uyandirSw;
    private boolean ilk;
    private LinearLayout sesKutu;
    private static final String ORNEK = "Merhaba! Ben senin asistanınım. Bugün iki ödemen var, istersen hatırlatayım.";
    private android.widget.CompoundButton.OnCheckedChangeListener balonDinle, uyandirDinle;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = new Prefs(this);
        yog = getResources().getDisplayMetrics().density;
        ilk = getIntent().getBooleanExtra("ilk", false);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF000000);
        LinearLayout k = new LinearLayout(this);
        k.setOrientation(LinearLayout.VERTICAL);
        k.setPadding(dp(18), dp(22), dp(18), dp(28));
        sv.addView(k);

        OrbView orb = new OrbView(this);
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(dp(130), dp(130));
        olp.gravity = Gravity.CENTER_HORIZONTAL;
        k.addView(orb, olp);

        TextView baslik = metin(ilk ? "Hoş geldin!" : "Telefon ayarları", 26, true, 0xFFFFFFFF);
        baslik.setGravity(Gravity.CENTER);
        k.addView(baslik);
        TextView alt = metin(ilk ? "Birkaç izin verelim, sonra asistanın hep elinin altında olsun. Her biri tek dokunuş."
                : "Yüzen küre, widget, sesle açılma ve bildirimler.", 15, false, 0xFFB9BEDA);
        alt.setGravity(Gravity.CENTER);
        alt.setPadding(0, dp(6), 0, dp(14));
        k.addView(alt);

        // --- izinler
        LinearLayout izin = kart(k, "İZİNLER");
        mikDurum = satirDugme(izin, "🎙️  Mikrofon", "Konuşarak komut vermek için", v -> {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, IZIN_MIK);
        });
        bildirimDurum = satirDugme(izin, "🔔  Bildirimler", "Fatura ve söz günü hatırlatmaları için", v -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, IZIN_BILDIRIM);
            else Toast.makeText(this, "Bildirimler zaten açık", Toast.LENGTH_SHORT).show();
        });
        ustDurum = satirDugme(izin, "🫧  Diğer uygulamaların üstünde göster", "Yüzen küre ve sesle açılma için gerekli", v -> overlayAyari());

        // --- yüzen küre
        LinearLayout yuzen = kart(k, "YÜZEN KÜRE");
        balonSw = anahtar(yuzen, "Yüzen asistanı göster", "Her ekranda küçük bir küre durur. Dokun: dinler. Sürükle: taşı. Uzun bas: kapat.");
        balonDinle = (s, acik) -> {
            prefs.balon(acik);
            if (acik) {
                if (!Settings.canDrawOverlays(this)) { overlayAyari(); return; }
                servisBaslat(BubbleService.class);
            } else {
                stopService(new Intent(this, BubbleService.class));
            }
        };
        balonSw.setOnCheckedChangeListener(balonDinle);

        // --- asistanın sesi
        sesKutu = kart(k, "ASİSTANIN SESİ");
        sesCiz();

        // --- sesle uyandırma
        LinearLayout ses = kart(k, "SESLE AÇILMA");
        uyandirSw = anahtar(ses, "Uyandırma kelimesiyle aç", "Telefon kilitliyken ya da yüzen balondayken “Asistan” veya asistanının adını söyle; “Sizi dinliyorum” der ve sorunu dinler. Tek nefeste de sorabilirsin: “Asistan, yarın hava nasıl?” Pil harcar.");
        TextView kl = metin("Uyandırma kelimesi (asistanının adı)", 13, false, 0xFFB9BEDA);
        kl.setPadding(0, dp(10), 0, dp(4));
        ses.addView(kl);
        EditText kelime = new EditText(this);
        kelime.setText(prefs.kelime());
        kelime.setTextColor(0xFFFFFFFF);
        kelime.setHintTextColor(0x88FFFFFF);
        kelime.setHint("ör. defne");
        kelime.setSingleLine(true);
        kelime.setBackground(yuvarlak(0x1AFFFFFF, 14, 0x33FFFFFF));
        kelime.setPadding(dp(14), dp(12), dp(14), dp(12));
        ses.addView(kelime, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        kelime.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) {}
            @Override public void afterTextChanged(Editable e) { prefs.kelime(e.toString().trim()); }
        });
        TextView ipucu = metin("İpucu: “Hey Google, " + getString(R.string.app_name) + " aç” dersen de açılır.", 13, false, 0xFF8F95B8);
        ipucu.setPadding(0, dp(10), 0, 0);
        ses.addView(ipucu);
        uyandirDinle = (s, acik) -> {
            prefs.uyandirma(acik);
            if (acik) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, IZIN_MIK);
                    return;
                }
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Kapalıyken açılabilmek için “üstünde göster” iznini de ver", Toast.LENGTH_LONG).show();
                    overlayAyari();
                    return;
                }
                stopService(new Intent(this, WakeService.class));
                servisBaslat(WakeService.class);
            } else {
                stopService(new Intent(this, WakeService.class));
            }
        };
        uyandirSw.setOnCheckedChangeListener(uyandirDinle);

        // --- widget
        LinearLayout w = kart(k, "ANA EKRAN");
        Button wb = buyukDugme("➕  Ana ekrana widget ekle");
        w.addView(wb);
        wb.setOnClickListener(v -> {
            AppWidgetManager m = getSystemService(AppWidgetManager.class);
            if (m != null && m.isRequestPinAppWidgetSupported()) {
                m.requestPinAppWidget(new ComponentName(this, AsistanWidget.class), null, null);
            } else {
                Toast.makeText(this, "Ana ekranda boş yere basılı tut → Widget'lar → " + getString(R.string.app_name), Toast.LENGTH_LONG).show();
            }
        });
        TextView wi = metin("Uygulama simgesine basılı tutarsan “Konuş” kısayolu da çıkar.", 13, false, 0xFF8F95B8);
        wi.setPadding(0, dp(8), 0, 0);
        w.addView(wi);

        Button bitir = buyukDugme(ilk ? "Hazırım, başlayalım ➜" : "Kapat");
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        blp.topMargin = dp(18);
        k.addView(bitir, blp);
        bitir.setOnClickListener(v -> {
            prefs.ilkKurulumBitti(true);
            finish();
        });

        setContentView(sv);
    }

    private void servisBaslat(Class<?> c) {
        try {
            startForegroundService(new Intent(this, c));
        } catch (Exception e) {
            Toast.makeText(this, "Başlatılamadı: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void overlayAyari() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            Toast.makeText(this, "Listeden “" + getString(R.string.app_name) + "”ı bul ve izni aç, sonra geri dön", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean mik = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean bil = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        boolean ust = Settings.canDrawOverlays(this);
        durum(mikDurum, mik);
        durum(bildirimDurum, bil);
        durum(ustDurum, ust);
        balonSw.setOnCheckedChangeListener(null);
        balonSw.setChecked(prefs.balon() && ust);
        balonSw.setOnCheckedChangeListener(balonDinle);
        if (prefs.balon() && ust) servisBaslat(BubbleService.class);
        sesCiz();
        sesKutu.postDelayed(this::sesCiz, 1500);
        boolean uy = prefs.uyandirma() && mik && ust;
        uyandirSw.setOnCheckedChangeListener(null);
        uyandirSw.setChecked(uy);
        uyandirSw.setOnCheckedChangeListener(uyandirDinle);
        if (uy && !WakeService.calisiyor) servisBaslat(WakeService.class);
    }

    @Override
    public void onRequestPermissionsResult(int kod, String[] izinler, int[] sonuc) {
        super.onRequestPermissionsResult(kod, izinler, sonuc);
        onResume();
    }

    // ---------- ses seçimi ----------
    private void sesCiz() {
        if (sesKutu == null) return;
        sesKutu.removeAllViews();
        final Seslendirici ss = Seslendirici.al(this);
        final boolean eleven = "eleven".equals(prefs.sesKaynak());
        final boolean erkek = "erkek".equals(prefs.cinsiyet());

        sesKutu.addView(secimSatiri(new String[]{"📱 Telefon sesi", "✨ ElevenLabs"}, eleven ? 1 : 0, i -> {
            prefs.sesKaynak(i == 1 ? "eleven" : "telefon");
            sesCiz();
        }));
        sesKutu.addView(secimSatiri(new String[]{"👩 Kadın", "👨 Erkek"}, erkek ? 1 : 0, i -> {
            prefs.cinsiyet(i == 1 ? "erkek" : "kadin");
            if ("eleven".equals(prefs.sesKaynak())) prefs.elevenSes((i == 1 ? Seslendirici.ERKEK : Seslendirici.KADIN)[0][1]);
            sesCiz();
        }));

        if (eleven) {
            TextView bilgi = metin("Çok gerçekçi, insan gibi ses. Ücretsiz hesapla ayda yaklaşık 10.000 kredi verilir; bu da aşağı yukarı 15-20 dakika konuşma eder. Hak bitince kendiliğinden telefon sesine geçerim.", 13, false, 0xFFA3A8C8);
            bilgi.setPadding(0, dp(10), 0, dp(6));
            sesKutu.addView(bilgi);
            sesKutu.addView(metin("1) elevenlabs.io'da ücretsiz hesap aç\n2) Profil → API Keys → Create\n3) Anahtarı aşağıya yapıştır", 14, false, 0xFFFFFFFF));
            TextView site = metin("elevenlabs.io'yu aç ➜", 14, true, 0xFF8FB8FF);
            site.setPadding(0, dp(8), 0, dp(8));
            site.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://elevenlabs.io/app/settings/api-keys"))); } catch (Exception ignored) {}
            });
            sesKutu.addView(site);
            EditText anahtar = new EditText(this);
            anahtar.setText(prefs.elevenKey());
            anahtar.setHint("API anahtarı (sk_...)");
            anahtar.setSingleLine(true);
            anahtar.setTextColor(0xFFFFFFFF);
            anahtar.setHintTextColor(0x88FFFFFF);
            anahtar.setBackground(yuvarlak(0x1AFFFFFF, 14, 0x33FFFFFF));
            anahtar.setPadding(dp(14), dp(12), dp(14), dp(12));
            anahtar.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence x, int a, int b2, int c) {}
                @Override public void onTextChanged(CharSequence x, int a, int b2, int c) {}
                @Override public void afterTextChanged(Editable e) { prefs.elevenKey(e.toString().trim()); }
            });
            sesKutu.addView(anahtar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            String[][] liste = erkek ? Seslendirici.ERKEK : Seslendirici.KADIN;
            for (String[] v : liste) {
                final String id = v[1];
                sesKutu.addView(sesSatiri(v[0], id.equals(prefs.elevenSes()), () -> {
                    prefs.elevenSes(id);
                    sesCiz();
                }, () -> {
                    if (prefs.elevenKey().isEmpty()) { Toast.makeText(this, "Önce API anahtarını yapıştır", Toast.LENGTH_SHORT).show(); return; }
                    prefs.elevenSes(id);
                    ss.konus(ORNEK, 1f);
                    sesCiz();
                }));
            }
        } else {
            java.util.List<android.speech.tts.Voice> hepsi = ss.turkceSesler();
            java.util.ArrayList<android.speech.tts.Voice> liste = new java.util.ArrayList<>();
            boolean bilinen = false;
            for (android.speech.tts.Voice v : hepsi) if (!Seslendirici.cinsiyetTahmini(v).isEmpty()) bilinen = true;
            for (android.speech.tts.Voice v : hepsi) {
                String t = Seslendirici.cinsiyetTahmini(v);
                if (!bilinen || t.isEmpty() || t.equals(erkek ? "Erkek" : "Kadın")) liste.add(v);
            }
            if (hepsi.isEmpty()) {
                TextView y = metin(ss.hazir() ? "Telefonunda Türkçe ses bulunamadı. Aşağıdan Türkçe ses verisini indir." : "Sesler yükleniyor…", 13, false, 0xFFA3A8C8);
                y.setPadding(0, dp(10), 0, dp(6));
                sesKutu.addView(y);
            } else if (!bilinen) {
                TextView y = metin("Telefonun sesleri kadın/erkek bilgisini vermiyor; dinleyip beğendiğini seç.", 13, false, 0xFFA3A8C8);
                y.setPadding(0, dp(10), 0, dp(2));
                sesKutu.addView(y);
            }
            int i = 1;
            for (android.speech.tts.Voice v : liste) {
                final String ad = v.getName();
                String t = Seslendirici.cinsiyetTahmini(v);
                String etiket = (t.isEmpty() ? "Ses " : t + " ses ") + i++ + (v.isNetworkConnectionRequired() ? " · internetle" : " · internetsiz");
                sesKutu.addView(sesSatiri(etiket, ad.equals(prefs.telefonSes()), () -> {
                    prefs.telefonSes(ad);
                    ss.telefonSesiniUygula();
                    sesCiz();
                }, () -> {
                    prefs.telefonSes(ad);
                    ss.telefonSesiniUygula();
                    ss.konus(ORNEK, 1f);
                    sesCiz();
                }));
            }
            TextView ek = metin("Daha fazla ses: telefonun Metin okuma ayarları ➜", 14, true, 0xFF8FB8FF);
            ek.setPadding(0, dp(10), 0, 0);
            ek.setOnClickListener(v -> {
                try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
                catch (Exception e) { Toast.makeText(this, "Ayarlar → Erişilebilirlik → Metin okuma", Toast.LENGTH_LONG).show(); }
            });
            sesKutu.addView(ek);
        }
    }

    private LinearLayout secimSatiri(String[] ad, int secili, java.util.function.IntConsumer tik) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(6), 0, dp(4));
        for (int i = 0; i < ad.length; i++) {
            final int no = i;
            TextView t = metin(ad[i], 15, true, i == secili ? 0xFFFFFFFF : 0xFFB9BEDA);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(8), dp(11), dp(8), dp(11));
            t.setBackground(i == secili ? yuvarlak(0xFF2F6BFF, 14, 0) : yuvarlak(0x14FFFFFF, 14, 0x22FFFFFF));
            t.setOnClickListener(v -> tik.accept(no));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(8);
            r.addView(t, lp);
        }
        return r;
    }

    private LinearLayout sesSatiri(String ad, boolean secili, Runnable sec, Runnable dinle) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(10), dp(10), dp(10));
        r.setBackground(secili ? yuvarlak(0x332F6BFF, 14, 0xFF2F6BFF) : yuvarlak(0x0AFFFFFF, 14, 0));
        TextView t = metin((secili ? "✓  " : "") + ad, 15, secili, 0xFFFFFFFF);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView d = metin("▶ Dinle", 13, true, 0xFFFFFFFF);
        d.setPadding(dp(12), dp(7), dp(12), dp(7));
        d.setBackground(yuvarlak(0x332F6BFF, 12, 0));
        d.setOnClickListener(v -> dinle.run());
        r.addView(d);
        r.setOnClickListener(v -> sec.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        r.setLayoutParams(lp);
        return r;
    }

    // ---------- küçük arayüz yardımcıları ----------
    private int dp(float v) { return (int) (v * yog); }

    private TextView metin(String s, float sp, boolean kalin, int renk) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(renk);
        if (kalin) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable yuvarlak(int renk, int r, int kenar) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(renk);
        g.setCornerRadius(dp(r));
        if (kenar != 0) g.setStroke(dp(1), kenar);
        return g;
    }

    private LinearLayout kart(LinearLayout k, String baslik) {
        TextView b = metin(baslik, 12, true, 0xFF8FA3D6);
        b.setLetterSpacing(0.18f);
        b.setPadding(dp(4), dp(16), 0, dp(8));
        k.addView(b);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(12), dp(16), dp(14));
        c.setBackground(yuvarlak(0x14FFFFFF, 22, 0x2E8C7CFF));
        k.addView(c, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return c;
    }

    private TextView satirDugme(LinearLayout c, String ad, String aciklama, View.OnClickListener tik) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, dp(10));
        LinearLayout sol = new LinearLayout(this);
        sol.setOrientation(LinearLayout.VERTICAL);
        sol.addView(metin(ad, 16, true, 0xFFFFFFFF));
        sol.addView(metin(aciklama, 13, false, 0xFFA3A8C8));
        r.addView(sol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView d = metin("İzin ver", 14, true, 0xFFFFFFFF);
        d.setPadding(dp(14), dp(9), dp(14), dp(9));
        d.setBackground(yuvarlak(0xFF2F6BFF, 14, 0));
        r.addView(d);
        r.setOnClickListener(tik);
        d.setOnClickListener(tik);
        c.addView(r);
        return d;
    }

    private void durum(TextView d, boolean tamam) {
        d.setText(tamam ? "✓ Tamam" : "İzin ver");
        d.setBackground(yuvarlak(tamam ? 0x3322C55E : 0xFF2F6BFF, 14, 0));
        d.setTextColor(tamam ? 0xFF4ADE80 : 0xFFFFFFFF);
    }

    private Switch anahtar(LinearLayout c, String ad, String aciklama) {
        Switch s = new Switch(this);
        s.setText(ad);
        s.setTextColor(0xFFFFFFFF);
        s.setTextSize(16);
        s.setTypeface(Typeface.DEFAULT_BOLD);
        s.setPadding(0, dp(8), 0, dp(4));
        c.addView(s, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        c.addView(metin(aciklama, 13, false, 0xFFA3A8C8));
        return s;
    }

    private Button buyukDugme(String yazi) {
        Button b = new Button(this);
        b.setText(yazi);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFF4D86FF, 0xFF1F5BFF});
        g.setCornerRadius(dp(18));
        b.setBackground(g);
        return b;
    }
}
