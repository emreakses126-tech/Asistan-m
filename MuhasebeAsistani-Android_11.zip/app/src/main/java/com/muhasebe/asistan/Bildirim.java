package com.muhasebe.asistan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Bildirim kanalları ve ortak bildirimler. */
public final class Bildirim {
    public static final String KANAL_SERVIS = "servis";
    public static final String KANAL_HATIRLATMA = "hatirlatma";
    public static final String KANAL_UYANDIR = "uyandir";
    public static final int UYANDIR_ID = 77;

    private Bildirim() {}

    public static void kanallar(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel s = new NotificationChannel(KANAL_SERVIS, "Arka plan (yüzen balon, sesle uyandırma)", NotificationManager.IMPORTANCE_MIN);
        s.setShowBadge(false);
        nm.createNotificationChannel(s);
        NotificationChannel h = new NotificationChannel(KANAL_HATIRLATMA, "Ödeme ve fatura hatırlatmaları", NotificationManager.IMPORTANCE_HIGH);
        h.enableVibration(true);
        nm.createNotificationChannel(h);
        NotificationChannel u = new NotificationChannel(KANAL_UYANDIR, "Asistan çağrıldığında", NotificationManager.IMPORTANCE_HIGH);
        u.setSound(null, null);
        u.enableVibration(false);
        u.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(u);
    }

    /** Arka plandan ekran açılamazsa (izin yoksa) tam ekran bildirimle asistanı öne getirir. */
    public static void uyandir(Context c, Intent i) {
        kanallar(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        PendingIntent pi = PendingIntent.getActivity(c, 901, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, KANAL_UYANDIR)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Sizi dinliyorum")
                .setContentText("Asistanı açmak için dokunun")
                .setCategory(Notification.CATEGORY_CALL)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setTimeoutAfter(15000)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build();
        try { nm.notify(UYANDIR_ID, n); } catch (Exception ignored) {}
    }

    public static void uyandirKapat(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(UYANDIR_ID);
    }

    public static PendingIntent uygulamayiAc(Context c, boolean dinle, int kod) {
        Intent i = new Intent(c, MainActivity.class);
        if (dinle) i.setAction(MainActivity.ACTION_DINLE);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, kod, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static Notification servis(Context c, String baslik, String metin) {
        kanallar(c);
        return new Notification.Builder(c, KANAL_SERVIS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(baslik)
                .setContentText(metin)
                .setOngoing(true)
                .setContentIntent(uygulamayiAc(c, true, 900))
                .build();
    }
}
