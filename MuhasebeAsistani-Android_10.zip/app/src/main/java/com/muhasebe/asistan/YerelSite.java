package com.muhasebe.asistan;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Arayüzü telefondan anında açar:
 *  1) Önce en son indirilen kopya (files/web), yoksa APK'nın içindeki kopya (assets/web) kullanılır.
 *  2) Arka planda sitedeki yeni sürüm kontrol edilir; değiştiyse indirilir, bir sonraki açılışta kullanılır.
 * Adres aynı kaldığı için giriş bilgileri ve kayıtlar kaybolmaz.
 */
public final class YerelSite {
    static final String HOST = "emreakses126-tech.github.io";
    static final String YOL = "/Asistan-m/";
    private static final String[] GUNCELLENEN = {"index.html", "ayar.js", "manifest.json"};

    private final Context ctx;
    private final File klasor;
    private final SharedPreferences sp;
    public volatile boolean yeniSurumHazir = false;

    public YerelSite(Context c) {
        ctx = c.getApplicationContext();
        klasor = new File(ctx.getFilesDir(), "web");
        if (!klasor.exists()) klasor.mkdirs();
        sp = ctx.getSharedPreferences("yerel_site", Context.MODE_PRIVATE);
    }

    private static String mime(String ad) {
        if (ad.endsWith(".html")) return "text/html";
        if (ad.endsWith(".js")) return "application/javascript";
        if (ad.endsWith(".json")) return "application/json";
        if (ad.endsWith(".png")) return "image/png";
        if (ad.endsWith(".svg")) return "image/svg+xml";
        if (ad.endsWith(".css")) return "text/css";
        return "application/octet-stream";
    }

    /** WebView isteği bizim sitemizin bir dosyasıysa telefondaki kopyadan ver. */
    public WebResourceResponse cevap(Uri u) {
        try {
            if (u == null || !"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return null;
            String yol = u.getPath() == null ? "" : u.getPath();
            if (!yol.startsWith(YOL) && !yol.equals("/Asistan-m")) return null;
            String ad = yol.length() <= YOL.length() ? "index.html" : yol.substring(YOL.length());
            if (ad.isEmpty()) ad = "index.html";
            if (ad.contains("/") || ad.contains("..")) return null;
            if (ad.equals("sw.js")) {
                // uygulama içinde çevrimdışı önbelleği biz yönetiyoruz: eski service worker kendini kaldırsın
                byte[] b = "self.addEventListener('install',()=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(self.registration.unregister()));".getBytes(StandardCharsets.UTF_8);
                return yanit("application/javascript", new ByteArrayInputStream(b));
            }
            InputStream in = null;
            File f = new File(klasor, ad);
            if (f.exists() && f.length() > 0) in = new FileInputStream(f);
            else {
                try { in = ctx.getAssets().open("web/" + ad); } catch (Exception ignored) { }
            }
            if (in == null) return null; // telefonda yoksa internetten gelsin
            return yanit(mime(ad), in);
        } catch (Exception e) {
            return null;
        }
    }

    private static WebResourceResponse yanit(String mime, InputStream in) {
        WebResourceResponse r = new WebResourceResponse(mime, "utf-8", in);
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        r.setResponseHeaders(h);
        return r;
    }

    /** Arka planda sitedeki yeni sürümü indir. Bir dosya değiştiyse true. */
    public boolean guncelle() {
        boolean degisti = false;
        for (String ad : GUNCELLENEN) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL("https://" + HOST + YOL + ad + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(15000);
                c.setRequestProperty("Cache-Control", "no-cache");
                String etag = sp.getString("etag_" + ad, null);
                if (etag != null && new File(klasor, ad).exists()) c.setRequestProperty("If-None-Match", etag);
                int kod = c.getResponseCode();
                if (kod == 304) continue;
                if (kod != 200) continue;
                File tmp = new File(klasor, ad + ".tmp");
                long toplam = 0;
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); toplam += n; }
                }
                // bozuk/yarım indirmeleri kullanma
                if (toplam < (ad.equals("index.html") ? 20000 : 10)) { tmp.delete(); continue; }
                File hedef = new File(klasor, ad);
                if (hedef.exists() && hedef.length() == tmp.length() && ayni(hedef, tmp)) { tmp.delete(); }
                else { if (hedef.exists()) hedef.delete(); if (tmp.renameTo(hedef)) degisti = true; }
                String yeniEtag = c.getHeaderField("ETag");
                if (yeniEtag != null) sp.edit().putString("etag_" + ad, yeniEtag).apply();
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }
        if (degisti) yeniSurumHazir = true;
        return degisti;
    }

    private static boolean ayni(File a, File b) {
        try (InputStream x = new FileInputStream(a); InputStream y = new FileInputStream(b)) {
            byte[] p = new byte[16384], q = new byte[16384];
            while (true) {
                int n = x.read(p), m = y.read(q);
                if (n != m) return false;
                if (n <= 0) return true;
                for (int i = 0; i < n; i++) if (p[i] != q[i]) return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
